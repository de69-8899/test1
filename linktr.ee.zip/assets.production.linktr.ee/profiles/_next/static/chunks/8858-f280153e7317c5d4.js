"use strict";
(self.__LOADABLE_LOADED_CHUNKS__ = self.__LOADABLE_LOADED_CHUNKS__ || []).push([
    [8858], {
        88858: function(e, t, i) {
            i.d(t, {
                Z: function() {
                    return p
                }
            });
            i(67294);
            var n = i(57502),
                a = i(59499),
                r = i(44301),
                o = i(94686),
                s = {
                    Header: {
                        title: "Translated Header title"
                    },
                    ContentWarning: {
                        title: "Sensitive Content",
                        ageWarning: "This profile may contain content that is not appropriate for all audiences",
                        accept: {
                            eighteenPlus: "I'm over 18",
                            twentyOnePlus: "I'm over 21",
                            twentyFivePlus: "I'm over 25",
                            generic: "Continue",
                            moderated: "Continue"
                        },
                        deny: {
                            eighteenPlus: "I'm under 18",
                            twentyOnePlus: "I'm under 21",
                            twentyFivePlus: "I'm under 25",
                            generic: "Go Back",
                            moderated: "Go Back"
                        }
                    },
                    Gate: {
                        iconLabel: {
                            locked: "locked",
                            loading: "loading",
                            unlocking: "unlocked",
                            unlocked: "unlocked"
                        },
                        recaptchaDisclaimer: "This Linktree is protected by reCAPTCHA and the Google {{privacyLink}} and {{termsLink}} apply.",
                        age: {
                            heading: {
                                initial: "Unlock link with your Date of Birth",
                                validating: "Checking your Date of Birth...",
                                invalid: "Unlock link with your Date of Birth"
                            },
                            invalidAge: "You can't access this content because you haven't met the minimum age requirement.",
                            cta: "Unlock"
                        },
                        passcode: {
                            heading: {
                                initial: "Unlock link with a code",
                                validating: "Checking code...",
                                invalid: "Unlock link with a code"
                            },
                            invalidCode: "You can't access this content because the code you entered is incorrect.",
                            cta: "Unlock"
                        },
                        nft: {
                            heading: {
                                initial: "Connect your Wallet to Access",
                                validating: "Checking MetaMask...",
                                invalid: "Connect your Wallet to Access"
                            },
                            cta: {
                                connect: "Connect Wallet",
                                unlock: "Unlock"
                            },
                            providers: {
                                metaMask: {
                                    connectionStatus: {
                                        success: "Connected to your wallet",
                                        error: "This content is only for owners of a NFT from the {{ collectionName }} collection."
                                    },
                                    notInstalled: {
                                        desktop: "Unlocking this link requires a MetaMask account. Please install MetaMask."
                                    },
                                    deeplinkCta: "Connect via MetaMask Browser"
                                }
                            },
                            options: {
                                title: "Select a Wallet",
                                wallets: {
                                    metaMask: {
                                        headline: "MetaMask",
                                        text: "Connect to your wallet"
                                    }
                                }
                            }
                        },
                        privacyPolicy: {
                            seeOur: "See our",
                            privacyPolicy: "privacy policy"
                        },
                        sensitiveContent: {
                            title: "Sensitive Content",
                            defaultMessage: "This link may contain content that is not appropriate for all audiences.",
                            cta: "Continue"
                        },
                        wall: {
                            title: "Sensitive Content",
                            defaultMessage: "This link is unavailable, as it does not comply with the guidelines of the platform you came from and is not meant for all audiences."
                        },
                        subscribed: {
                            title: "Unlock by Subscribing",
                            defaultMessage: "Enter your details to be notified about new content on this Linktree."
                        },
                        payment: {
                            errors: {
                                generic: "Something went wrong, please try again shortly.",
                                "bad.phone_number": "Please enter a valid phone number",
                                invalid_grant: "This code has expired. Please request a new one.",
                                access_denied: "Incorrect code. Please try again."
                            },
                            initial: {
                                title: "Unlock this content",
                                cta: {
                                    pay: "Pay {{amount}}",
                                    returning: "I've already paid"
                                },
                                links: {
                                    privacy: "See our {{privacyLink}}",
                                    faq: "See {{faqsLink}} about this purchase"
                                }
                            },
                            returningUser: {
                                title: "Welcome back!",
                                body: {
                                    thanks: "Thanks for your payment.",
                                    search: "Search @{{username}} in your email for the link to unlock this content.",
                                    linkText: "Can't find it?"
                                }
                            },
                            emailVerification: {
                                title: "Unlock this content",
                                subHeader: "Verify your email",
                                body: "After you've paid, we'll email you an invoice and a link to access the content again (and again and again).",
                                emailLabel: "Email address",
                                submit: "Next"
                            },
                            OTC: {
                                title: "Unlock this content",
                                subHeader: "Email sent",
                                body: "We've sent a 6-digit code to {{emailAddress}}. Please enter the code below.",
                                submit: "Confirm"
                            },
                            payment: {
                                subtitle: "to {{username}}"
                            },
                            success: {
                                title: "Your payment was successful",
                                body: "We've sent a receipt and a link to access this content again to <bold>{{emailAddress}}</bold>",
                                viewContent: "View content"
                            }
                        }
                    },
                    LinkClubhouse: {
                        error: "Sorry, something went wrong. Our team has been notified and we are working on getting this fixed."
                    },
                    LinkTikTokProfile: {
                        error: "Sorry, something went wrong. Our team has been notified and we are working on getting this fixed.",
                        preview: {
                            followCTA: "Follow",
                            followers: "followers",
                            profileThumbnailAlt: "Profile picture for {{username}}",
                            videoThumbnailAlt: {
                                latest: "Thumbnail for {{usernames}}'s latest video",
                                previous: "Thumbnail for {{usernames}}'s previous video"
                            }
                        }
                    },
                    LinkContactForm: {
                        submittingTo: "By submitting your contact details, you are providing your data to",
                        contactYou: "who may contact you.",
                        cta: "Send",
                        submissionSuccess: "Message sent successfully",
                        closeButton: "Close",
                        errors: {
                            name: "Please enter a name",
                            mobile: "Please enter a valid phone number",
                            message: "Please enter a message",
                            submission: "That is an error. Our bad. Please try again.",
                            required: "Field required",
                            email: "Please enter a valid email address"
                        }
                    },
                    LinkFormV2Form: {
                        subscribeTermsAndPrivacy: "By submitting, you agree to Linktree's {{termsLink}} and {{privacyLink}}, and to your contact details being shared with {{username}}, who may contact you.",
                        termsLinkTextShort: "T&Cs",
                        privacyLinkText: "Privacy Notice",
                        submittingTo: "By submitting your contact details, you are providing your data to",
                        contactYou: "who may contact you.",
                        cta: "Send",
                        submissionSuccess: "Message sent successfully",
                        closeButton: "Close",
                        required: "(required)",
                        optional: "(optional)",
                        errors: {
                            TEXT: "Please enter a name",
                            EMAIL: "Please enter a valid email address",
                            PHONE: "Please enter a valid phone number",
                            MESSAGE: "Please enter a message",
                            DATE: "Please enter a valid date",
                            RADIO: "Please select an option",
                            CHECKBOX: "Please select an option",
                            submission: "That is an error. Our bad. Please try again."
                        },
                        previewLabel: "Enter {{label}}",
                        previewLabelFallback: "Enter email"
                    },
                    LinkContactDetails: {
                        contactTypeOptions: {
                            HOME: "Home",
                            MOBILE: "Mobile",
                            OTHER: "Other",
                            PERSONAL: "Personal",
                            WORK: "Work"
                        },
                        recaptchaDisclaimer: "This Linktree is protected by reCAPTCHA and the Google {{privacyLink}} and {{termsLink}} apply.",
                        recaptchaVerification: "Verifying your identity..."
                    },
                    UnverifiedProfileBanner: {
                        message: "Only you can see your profile until you verify your account. Click the link we have sent to your email to publish your profile.",
                        successMessage: "Thanks we\u2019ve resent a verification link to your email address, check your inbox.",
                        errorMessage: "Sorry, we had a problem trying to resend the verification email, please try again.",
                        cta: "Resend verification link"
                    },
                    LinkSignup: {
                        termsMessage: {
                            EMAIL: "By submitting your contact details, you are providing your data to {{username}}, who may contact you.",
                            PHONE: "By submitting your contact details, you are providing your data to {{username}}, who may contact you."
                        },
                        errorMessage: "Something went wrong...",
                        submit: "Submit",
                        validationMessage: {
                            EMAIL: "Please enter a valid email address",
                            PHONE: "Please enter a valid phone number"
                        }
                    },
                    LinkPay: {
                        label: "Pay",
                        paymentLabel: {
                            square: "Payment method",
                            stripe: "Payment details",
                            paypal: "Payment options"
                        },
                        continueToPayButton: "Continue to pay",
                        emailLabel: "Details",
                        emailPlaceholder: "Email address",
                        noteLabel: "Message",
                        notePlaceholder: "Leave a message (optional)",
                        helpCoverFeesLabel: "Cover processor fees <bold>(+ {{ amount }}).</bold>",
                        helpCoverFeesDescription: "These are fees a seller pays when a customer makes a purchase. <a>Learn more</a>",
                        amountCurrency: "{{amount}} ({{currencyCode}})",
                        toUser: "to {{username}}",
                        recaptchaDisclaimer: "This Linktree is protected by reCAPTCHA and the Google {{privacyLink}} and {{termsLink}} apply.",
                        disclaimer: {
                            tncAgree: {
                                square: "By clicking pay, you agree to the",
                                stripe: "By clicking pay, you agree to the",
                                paypal: "By completing this transaction, you agree to the"
                            },
                            terms: "T&Cs",
                            liabilityClause: {
                                LinkPay: "Payment will be made to {{username}}. Linktree is not liable for this transaction.",
                                LinkRequest: "Payment will be made to {{username}}. Linktree is not liable for this transaction or the item/service you purchase."
                            }
                        },
                        amountSelector: {
                            amountLabelCurrency: "Select an amount ({{currencyCode}})",
                            amountLabel: "Select an amount",
                            customAmountCurrency: "or custom amount ({{currencyCode}})",
                            customAmount: "or custom amount",
                            continue: "Continue",
                            error: {
                                empty: "You need to select an amount to continue",
                                maxExceeded: "This amount is too high, please set a lower amount",
                                minExceeded: "This amount is too low, please set a higher amount"
                            }
                        },
                        paymentForm: {
                            securePayment: "Making secure payment to",
                            username: "{{username}}"
                        },
                        successMessage: "Your payment was successful",
                        viewReceipt: "View your receipt",
                        receiptEmailedTo: "Receipt emailed to",
                        close: "Close",
                        errors: {
                            internal: "Unable to process your payment, please try again shortly.",
                            InvalidEmailException: "Supplied email address is invalid",
                            InvalidCaptchaException: "Unable to verify your request, please try again",
                            InvalidPaymentTitleException: "Order title must not be empty",
                            InvalidPaymentNoteException: "Note must be less than 200 characters",
                            InvalidPaymentAmountException: "Supplied amount must be a number and greater than 0",
                            CARD_EXPIRED: "The card issuer declined the request because the card is expired.",
                            INVALID_EXPIRATION: "The expiration date for the payment card is invalid.",
                            INVALID_EXPIRATION_YEAR: "The expiration year for the payment card is invalid.",
                            INVALID_EXPIRATION_DATE: "The expiration date for the payment card is invalid.",
                            UNSUPPORTED_CARD_BRAND: "The credit card provided is not from a supported issuer.",
                            UNSUPPORTED_ENTRY_METHOD: "The entry method for the credit card (swipe, dip, tap) is not supported.",
                            INVALID_ENCRYPTED_CARD: "The encrypted card information is invalid.",
                            INVALID_CARD: "The credit card cannot be validated based on the provided details.",
                            PAYMENT_LIMIT_EXCEEDED: "This amount is too high. Please change to a lower amount.",
                            INVALID_POSTAL_CODE: "The postal code is invalid.",
                            GENERIC_DECLINE: "An unexpected error occurred, contact your card issuer for more information.",
                            VERIFY_CVV_FAILURE: "The card issuer declined the request because the CVV value is invalid.",
                            CVV_FAILURE: "The card issuer declined the request because the CVV value is invalid.",
                            INSUFFICIENT_FUNDS: "You have insufficient funds to proceed with this payment.",
                            CARDHOLDER_INSUFFICIENT_PERMISSIONS: "This card cannot be used for this payment.",
                            INVALID_LOCATION: "This card cannot be used for this payment.",
                            CARD_NOT_SUPPORTED: "This card cannot be used for this payment.",
                            ADDRESS_VERIFICATION_FAILURE: "The card issuer declined the request because the postal code is invalid.",
                            AMOUNT_TOO_HIGH: "This amount is too high. Please change to a lower amount.",
                            INVALID_CARD_DATA: "The credit card cannot be validated based on the provided details.",
                            CARD_DECLINED: "There was a problem processing the payment on this card. Please try another card.",
                            VALUE_TOO_LOW: "The amount is below the minimum allowed amount. Please choose a higher amount",
                            VALUE_TOO_HIGH: "The amount is above the maximum amount. Please choose a lower amount.",
                            VOICE_FAILURE: "The card issuer declined the request because voice authorization is required from the card holder.",
                            TRANSACTION_LIMIT: "The card issuer has declined the request because the card has reached the transaction limit.",
                            PAN_FAILURE: "The card number is not valid. Check that the length and format are correct.",
                            VALIDATION_ERROR: {
                                cardNumber: "Card number is not valid",
                                cvv: "CVV number is not valid",
                                expirationDate: "Expiration date is not valid",
                                generic: "Card details are invalid"
                            }
                        },
                        squareSca: {
                            initialAttempt: {
                                reason: "Your bank requires additional information to securely verify your payment.",
                                cta: "Please complete the details below."
                            },
                            failure: {
                                reason: "Verification Failed",
                                cta: "Please check the details entered. To pass verification, they must match your bank's records."
                            },
                            inputPlaceholders: {
                                firstName: "First Name",
                                lastName: "Last Name",
                                address1: "Address line 1",
                                address2: "Address line 2",
                                cityTown: "City/Town",
                                country: "Country",
                                postCode: "Post Code"
                            },
                            verificationFieldsHeader: "Details for bank verification"
                        }
                    },
                    LinkRequest: {
                        amountSelector: {
                            selectAndContinue: "Select an option to continue",
                            continueButtonCurrency: "Continue {{amount}} ({{currencyCode}})",
                            continueButton: "Continue {{amount}}"
                        },
                        emailPlaceholder: "Email address",
                        emailLabel: "Details",
                        notePlaceholder: "Provide special instructions or details",
                        noteLabel: "Request instructions"
                    },
                    LinkDigitalProduct: {
                        productDetailPage: {
                            accessTo: "Access to",
                            group: "group",
                            defaultButtonCTA: "Checkout",
                            free: "Free"
                        },
                        productAccessPage: {
                            accessButtonLoading: "Your {{productType}} will be available shortly",
                            accessButtonCTA: "Access {{productType}}"
                        },
                        checkoutPage: {
                            buttonCTA: "Submit",
                            infoDisclaimer: "Join the mailing list to get this for free",
                            nameLabel: "Your name",
                            emailLabel: "Email",
                            infoHeader: "Your information",
                            termsAndConditionsUsernameDefault: "this user",
                            termsAndConditions: 'By submitting, you agree to Linktree\'s <a class="underline" href="https://linktr.ee/s/terms" target="_blank" rel="noopener noreferrer">T&Cs</a>, <a class="underline" href="https://linktr.ee/s/privacy" target="_blank" rel="noopener noreferrer">Privacy Notice</a>, and to sharing your information with {{username}}',
                            freeCheckoutTermsROW: "By unlocking this content, you agree to receive updates and promotions from {{username}}.",
                            subscriptionConsentCheckbox: "Join {{username}}\u2019s mailing list"
                        },
                        confirmationPage: {
                            getStarted: "Get started",
                            avatarAlt: "Profile Avatar",
                            free: "Free",
                            existingPurchaseActive: {
                                header: "An existing purchase was found with this email address",
                                description: "An email was sent to you with a link to access the content."
                            },
                            existingPurcahsePending: {
                                header: "This product has been successfully purchased but is still processing",
                                description: "We'll send you an email with access when processing is complete."
                            }
                        },
                        error: "Sorry, something went wrong. Our team has been notified and we are working on getting this fixed.",
                        paymentPage: {
                            paymentDetails: "Payment Details",
                            paymentImplementation: "Payment form implementation coming soon..."
                        }
                    },
                    LinkKajabiCourse: {
                        courseOutline: "Course Outline",
                        moduleDescription: "Module {{moduleNumber}}&nbsp;&nbsp;\u2022&nbsp;&nbsp;{{lessonCount}} Lessons&nbsp;&nbsp;\u2022&nbsp;&nbsp;{{duration}}",
                        moduleDescriptionNoDuration: "Module {{moduleNumber}}&nbsp;&nbsp;\u2022&nbsp;&nbsp;{{lessonCount}} Lessons",
                        lessonDescription: "{{title}} \u2022 {{duration}}",
                        productType: "Course",
                        linkPreview: {
                            enroll: "Enroll in course"
                        }
                    },
                    LinkProduct: {
                        zeroProducts: "There are currently no products available. Please check back later.",
                        cta: {
                            shopStore: "Shop The Entire Store",
                            shopCollection: "Shop The Entire Collection"
                        },
                        error: "Sorry, something went wrong. Our team has been notified and we are working on getting this fixed."
                    },
                    LinkSocialFeed: {
                        error: "Sorry, something went wrong. Our team has been notified and we are working on getting this fixed.",
                        postDetail: {
                            close: "Close",
                            exploreLinks: "Explore links:"
                        },
                        postDialog: {
                            titleInstagram: "Instagram",
                            titleTikTok: "TikTok"
                        }
                    },
                    LinkSpring: {
                        zeroProducts: "There are currently no products available. Please check back later.",
                        cta: {
                            withproductCount: "Shop my {{productCount}} products",
                            withoutproductCount: "Shop my store"
                        },
                        error: {
                            title: "Oops! Something went wrong...",
                            line1: "We can't seem to find the store you are looking for.",
                            line2: "Please try again later."
                        }
                    },
                    LinkChatbot: {
                        title: "Hello world",
                        submitBtn: "Send",
                        assistantTimestamp: "AI powered \u2022 {{timestamp}}",
                        feedbackPrompt: "Was this response helpful?",
                        feedbackYes: "Yes",
                        feedbackNo: "No",
                        emptyMessages: "Start asking a question...",
                        recentlySentMessage: "Just now",
                        inputLabel: "Ask a question",
                        initialAssistantMessage: "Have a question? Fire away",
                        messageSendError: "Sorry, something went wrong. Please try asking the question again later.",
                        maxInputLengthError: "Question cannot be longer than 500 characters"
                    },
                    LinkMusic: {
                        audioPreviewOutboundLink: {
                            label: "Open in {{platform}}"
                        },
                        audioPreviewError: {
                            title: "Oops! Something went wrong...",
                            line1: "We can't seem to find the content you're looking for.",
                            line2: "Please try again later."
                        },
                        links: {
                            heading: "Listen on",
                            affiliateDisclaimer: "These links may earn {{target}} ",
                            affiliateDisclaimerGenericUser: "the creator",
                            affiliateDisclaimerLink: "affiliate revenue",
                            showMore: "Show more",
                            showLess: "Show less"
                        },
                        link: {
                            ariaLabel: "Listen to {{title}} by {{artistName}} on {{platform}}"
                        },
                        preview: {
                            spotifyArtistSubheader: "Top Tracks"
                        }
                    },
                    LinkPreSave: {
                        presaveCtaHeading: "Pre-save",
                        presaveCtaHeadingComplete: "Pre-saved",
                        availableHeader: "Available",
                        links: {
                            affiliateDisclaimer: "These links may earn {{target}} ",
                            affiliateDisclaimerGenericUser: "the creator",
                            affiliateDisclaimerLink: "affiliate revenue",
                            showMore: "Show more",
                            showLess: "Show less",
                            ariaLabel: "Listen to ${songTitle} by ${artist} on {provider}"
                        },
                        finished: {
                            heading: "Pre-save complete",
                            paragraph: "{{title}} will be available in your {{platform}} library on {{releaseDateTime}}",
                            close: "Close"
                        },
                        link: {
                            ariaLabel: "Listen to {{title}} by {{artistName}} on {{platform}}"
                        }
                    },
                    LinkNftGallery: {
                        noImage: "NO IMAGE",
                        verified: "Verified",
                        listEmpty: "There are currently no NFTs to display.",
                        viewFullCollection: "View Full Collection"
                    },
                    LinkBook: {
                        contributorsSeparator: ", ",
                        contributorsAbbreviated: "and others",
                        bookPreviewOutboundLink: {
                            label: "Open in {{platform}}"
                        },
                        scrollContainer: {
                            seeAll: "See all",
                            scrollAriaLabelLeft: "Scroll filters left.",
                            scrollAriaLabelRight: "Scroll filters right."
                        },
                        metadata: {
                            noThumbnail: "Cover coming soon"
                        },
                        links: {
                            availableOutsideRegion: "Available outside your region",
                            seeAllOptions: "See all",
                            linkLoadError: "There was a problem loading links...",
                            affiliateDisclaimer: "These links may earn {{target}} ",
                            affiliateDisclaimerGenericUser: "the creator",
                            affiliateDisclaimerLink: "affiliate revenue"
                        },
                        link: {
                            ariaLabel: "Purchase {{title}} by {{contributorNames}} on {{platform}}",
                            newAndUsedFrom: "From ",
                            free: "Free",
                            noPriceAvailable: "Check price and availability"
                        },
                        productCondition: {
                            new: "New",
                            used: "Used",
                            newAndUsed: "New and Used"
                        },
                        filters: {
                            massMarket: "Mass Market",
                            audiobook: "Audiobook",
                            paperBack: "Paperback",
                            hardCover: "Hardcover",
                            eBook: "Ebook"
                        },
                        sortOrder: {
                            asc: "Price: Low to high",
                            desc: "Price: High to low",
                            recommended: "Recommended"
                        },
                        purchasingOptions: {
                            sortHeader: "Sort by",
                            sortHeaderAria: "Sort links",
                            filterHeader: "Filter",
                            filterHeaderAria: "Filter links",
                            emptyResults: "You have filters applied which may be hiding some results.",
                            clearFilter: "Clear Filter"
                        },
                        purchasingOptionsDropdown: {
                            sort: {
                                header: "Sort by",
                                labelRecommended: "Recommended",
                                labelAsc: "Price: Low to high",
                                labelDesc: "Price: High to low",
                                labelDone: "Done"
                            },
                            filter: {
                                header: "Filter",
                                subHeader: "Condition",
                                labelNew: "New only",
                                labelUsed: "Used only",
                                labelNewAndUsed: "New and used",
                                labelDone: "Done"
                            }
                        },
                        loading: {
                            message1: "Searching retailers...",
                            message2: "Scanning book shelves...",
                            message3: "Flicking pages..."
                        }
                    },
                    LinkYoutube: {
                        preview: {
                            latestVideo: "Latest video \u2022 {{date}}",
                            subscribers: "subscribers",
                            subscribeCTA: "Subscribe",
                            thumbnailAlt: "Latest Video Post Thumbnail"
                        }
                    },
                    LinkInstagram: {
                        preview: {
                            postAltText: "Instagram post",
                            profileThumbnailAltText: "Profile picture of @{{username}}",
                            followers: "followers",
                            follow: "Follow"
                        },
                        morePostsPreview: "+ {{totalPostsCount}} more"
                    },
                    LinkTwitter: {
                        preview: {
                            postDate: "{{time}} \u2022 {{date}}",
                            noPost: "No post available",
                            thumbnailAlt: "Twitter Post's Last Thumbnail Image"
                        }
                    },
                    LinkPodcast: {
                        description: {
                            seeMoreButton: {
                                label: "See more",
                                ariaLabel: "See full description."
                            }
                        },
                        links: {
                            affiliateDisclaimer: "These links may earn {{target}} ",
                            affiliateDisclaimerLink: "affiliate revenue",
                            affiliateDisclaimerGenericUser: "the creator",
                            scrollAriaLabelLeft: "Scroll links left.",
                            scrollAriaLabelRight: "Scroll links right."
                        },
                        link: {
                            ariaLabel: "Open {{title}} on {{platform}}"
                        },
                        showModal: {
                            seeAll: "See all",
                            contentLabel: "Open {{title}} on the podcast platform of your choice.",
                            heading: "Listen on",
                            close: "Close"
                        },
                        showInformationModal: {
                            episode: {
                                about: "Episode description"
                            },
                            show: {
                                about: "Show description"
                            }
                        },
                        recentEpisodes: {
                            heading: "Recent episodes"
                        },
                        recentEpisode: {
                            ariaLabel: 'Listen to the episode titled "{{title}}" on the podcast platform of your choice.'
                        },
                        recentEpisodesModal: {
                            heading: "Options",
                            listenToEpisode: "Listen to episode",
                            openShow: "Open show",
                            openShowSubHeading: "You'll be taken to {{title}}"
                        }
                    },
                    LinkMobileApp: {
                        links: {
                            heading: "Available on"
                        },
                        singleAppAvailableButton: {
                            label: "Download on {{platform}}"
                        },
                        link: {
                            ariaLabel: "Download {{title}} on {{platform}}"
                        }
                    },
                    LinkPinterest: {
                        cta: "View on Pinterest"
                    },
                    LinkCommunity: {
                        linkPreview: {
                            accessToPlatform: "Access to {{platform}}"
                        },
                        enterCommunity: "Enter community",
                        joinCommunity: "Join the community",
                        hostedOn: "Hosted on",
                        features: "Features",
                        error: {
                            unknown: "An unknown error occurred"
                        },
                        join: "Join",
                        joinForFree: "Join for free",
                        joinForFreeWHATSAPP: "Join group for free",
                        joinForFreeDISCORD: "Join server for free",
                        joinForFreeSLACK: "Join workspace for free",
                        formSubmittedSuccessfully: "Form Submitted Successfully",
                        confirmationInstructions: {
                            header: "Form Submitted Successfully",
                            description: "Your access to the community has been emailed to you along with a receipt for your transaction. "
                        },
                        confirmationButtonCTA: "Join {{platform}}",
                        confirmationMessage: "Your access to the community has been emailed to you along with a receipt for your transaction.",
                        community: "community",
                        whatsappGroup: "WhatsApp group",
                        discordServer: "Discord server",
                        slackWorkspace: "Slack workspace"
                    },
                    CauseBanner: {
                        title: {
                            [o.CauseTypes.BLM]: "Support Anti-Racism",
                            [o.CauseTypes.GOFUNDME_GIVINGTREE_2020]: "The Giving Tree",
                            [o.CauseTypes.ANTIWAR]: "War is not the answer.",
                            [o.CauseTypes.TURKEY_SYRIA_EARTHQUAKE]: "Help T\xfcrkiye and Syria",
                            [o.CauseTypes.PRIDE_2023]: "Protect LGBTQIA+ rights",
                            [o.CauseTypes.VOTER_REGISTRATION]: "Are you ready to vote?",
                            [o.CauseTypes.WORLD_MENTAL_HEALTH_DAY]: "Support Mental Health",
                            [o.CauseTypes.LA_FIRES]: "Los Angeles fire relief"
                        },
                        description: {
                            [o.CauseTypes.BLM]: "I'm raising awareness, driving donations and sharing information in support of racial justice and equality. Will you join me?",
                            [o.CauseTypes.GOFUNDME_GIVINGTREE_2020]: "I'm inviting you to help support those in need this holiday season.",
                            [o.CauseTypes.ANTIWAR]: "I'm driving awareness, donations and support to #StandWithUkraine, and the right for people everywhere to live in peace. Will you join me?",
                            [o.CauseTypes.TURKEY_SYRIA_EARTHQUAKE]: "I'm raising awareness and funds for the people impacted by the T\xfcrkiye-Syria earthquake. Join me.",
                            [o.CauseTypes.PRIDE_2023]: "In celebration of Pride, I'm raising awareness and funds to support the LGBTQIA+ community. Join me.",
                            [o.CauseTypes.VOTER_REGISTRATION]: "Check your U.S. voter registration and make sure you\u2019re ready to vote in the next election",
                            [o.CauseTypes.WORLD_MENTAL_HEALTH_DAY]: "I'm raising awareness, driving donations, and sharing resources in support of mental health.",
                            [o.CauseTypes.LA_FIRES]: "I'm raising funds for the people, animals and emergency services impacted by the LA fires. Join me."
                        },
                        cta: {
                            [o.CauseTypes.BLM]: "ACT NOW",
                            [o.CauseTypes.GOFUNDME_GIVINGTREE_2020]: "START GIVING",
                            [o.CauseTypes.ANTIWAR]: "ACT NOW",
                            [o.CauseTypes.TURKEY_SYRIA_EARTHQUAKE]: "ACT NOW",
                            [o.CauseTypes.PRIDE_2023]: "ACT NOW",
                            [o.CauseTypes.VOTER_REGISTRATION]: "Check your registration",
                            [o.CauseTypes.WORLD_MENTAL_HEALTH_DAY]: "ACT NOW",
                            [o.CauseTypes.LA_FIRES]: "ACT NOW"
                        }
                    },
                    Form: {
                        charactersLeft: "{{charsLeft}} characters left",
                        countryDefaultOption: "Country"
                    },
                    SignupCta: {
                        linktreeUrl: "linktr.ee/",
                        joinLinkTree: "Join {{username}} on Linktree",
                        joinLinkTreeToday: "Join {{username}} on Linktree today",
                        claimYours: "Claim your Linktree"
                    },
                    SignupOption: {
                        titleText: "Join {{username}} on Linktree",
                        subTitleText: "Get your own free Linktree. The only link in bio trusted by 50M+ people.",
                        signupCtaText: "Sign up free",
                        homePageCtaText: "Find out more"
                    },
                    SignupIntentModal: {
                        title: "Join the only link in bio trusted by 50M+",
                        user_types: {
                            creators: "creators",
                            businesses: "businesses",
                            musicians: "musicians",
                            realtors: "realtors",
                            creatives: "creatives"
                        },
                        description: "One link to share everything you create, curate and sell across IG, TikTok and more.",
                        button_claim: "Claim your Linktree",
                        subscribe_to: "Subscribe to @{{username}}",
                        explore_more: "Explore more Linktrees",
                        learn_more: "Learn more about Linktree",
                        button_signup_free: "Sign up free"
                    },
                    Follow: {
                        subscribe: "Subscribe",
                        subscribed: "Subscribed",
                        subscribeTo: "Subscribe to {{displayName}}",
                        unsubscribeModal: {
                            heading: "Unsubscribe?",
                            description: "You won't be notified when {{displayName}} shares something important.",
                            cancelButton: "Cancel",
                            confirmButton: "Yes, unsubscribe"
                        },
                        agreeToShareModal: {
                            heading: "Subscribe to {{username}}",
                            description: "You'll be notified when {{displayName}} shares something important to them.",
                            checkbox: "I agree to my contact details being shared with {{ username }}, who may contact me. {{optionalText}}",
                            confirmButton: "Subscribe",
                            cancelButton: "Cancel",
                            optionalText: "(Optional)"
                        },
                        tabs: {
                            smsLabel: "SMS",
                            whatsappLabel: "WhatsApp",
                            emailLabel: "Email"
                        },
                        enterDetails: "Stay up to date with everything important.",
                        emailAddress: "Email",
                        phonePlaceholder: "Phone number",
                        submit: "Subscribe",
                        terms: "I agree to Linktree's {{termsLink}} and {{privacyLink}}. {{requiredText}}",
                        termsLinkText: "Terms and Conditions",
                        termsLinkTextShort: "T&Cs",
                        privacyLinkText: "Privacy Notice",
                        requiredText: "(Required)",
                        agreeToShare: "I agree to my contact details being shared with {{username}}, who may contact me.",
                        subscribeTermsAndPrivacy: "By subscribing, you agree to Linktree's {{termsLink}} and {{privacyLink}}, and to your contact details being shared with {{username}}, who may contact you.",
                        subscribeAgreeToShare: "By subscribing, you agree to your contact details being shared with {{username}}, who may contact you.",
                        errors: {
                            emailRequired: "Please enter a valid email address",
                            phoneNumberRequired: "Please enter a valid phone number",
                            whatsappNumberRequired: "Please enter a valid phone number",
                            email: "Please enter a valid email address",
                            phoneNumber: "Please enter a valid phone number",
                            terms: "Please agree to our T&Cs and Privacy Notice",
                            emailAndTerms: "Please enter a valid email address and agree to our T&Cs and Privacy Notice",
                            emailAndPhoneNumberAndTerms: "Please enter a valid email address or phone number, and agree to our T&Cs and Privacy Notice",
                            code: "Incorrect code. Please try again.",
                            authenticatingRecaptcha: "One time code could not be sent.  Please try again.",
                            invalidRecaptcha: "Invalid reCAPTCHA. Please try again."
                        },
                        otcHeadingEmail: "Confirm your email address",
                        otcHeadingPhoneNumber: "Confirm your phone number",
                        otcHeadingWhatsappNumber: "Confirm your phone number",
                        otcMessage: "We've sent a 6-digit code to <0>{{otpMethodValue}}</0>.<br />Enter it below.",
                        confirm: "Confirm",
                        requestCode: "Request a new code",
                        subscribedConfirmation: "Subscribed to {{ username }}",
                        unsubscribedConfirmation: "Unsubscribed from {{ username }}",
                        subscribedError: "Failed to subscribe to {{ username }}. Please try again.",
                        unsubscribedError: "Failed to unsubscribe from {{ username }}. Please try again.",
                        previewTooltip: "Visitors can register to be notified about new content",
                        recaptchaDisclaimer: "This Linktree is protected by reCAPTCHA and the Google {{privacyLink}} and {{termsLink}} apply.",
                        recaptchaVerification: "Verifying your identity...",
                        logOut: "Log out",
                        notYou: "Not you?"
                    },
                    Web3: {
                        nftVerification: "NFT Verification",
                        nftVerified: "Verified",
                        openseaVerified: "Verified by Opensea",
                        ethVerified: "Externally Verified"
                    },
                    ShareModalAccount: {
                        title: "Share Linktree",
                        description: ""
                    },
                    ShareModalCommerceCollection: {
                        title: "Share this collection",
                        titleShareLinkPreview: "Share collection",
                        description: ""
                    },
                    ShareModalCommerceProduct: {
                        title: "Share this product",
                        titleShareLinkPreview: "Share product",
                        description: ""
                    },
                    ShareModalLink: {
                        title: "Share link",
                        description: ""
                    },
                    LinkLinkerRecommendations: {
                        recommendationLink: "View Linktree"
                    },
                    Footer: {
                        ctaLinkText: "Create your own",
                        cookiePreferencesLinkText: "Cookie preferences",
                        linkAffiliateDisclaimer: "Links may earn commission",
                        productAffiliateDisclaimer: "Products may contain affiliate links"
                    },
                    MeatballMenu: {
                        reportLinktree: "Report Linktree",
                        moreButtonText: "More",
                        lessButtonText: "Less"
                    },
                    TextLinkApp: {
                        title: "More"
                    },
                    MapsLinkAppPreview: {
                        title: "Directions"
                    },
                    MediaKit: {
                        PlatformOverview: {
                            title: "Platform overview"
                        },
                        Carousel: {
                            goToPage: "Go to page {{page}}",
                            imageAlt: "Featured hero image {{page}}"
                        },
                        Brands: {
                            title: "Brands I have worked with"
                        },
                        ContactForm: {
                            getInTouch: "Get in touch",
                            profileAlt: "Profile picture for {{username}}"
                        },
                        Dialog: {
                            close: "Close",
                            ariaLabel: "Close dialog"
                        },
                        Image: {
                            alt: "Social media post"
                        },
                        PostTypeSelector: {
                            latestPosts: "Latest Posts",
                            reelsOnly: "Reels Only"
                        },
                        ImageGallery: {
                            next: "Next gallery page",
                            previous: "Previous gallery page",
                            goToPage: "Go to gallery page {{page}}",
                            noPostsAvailable: "No posts available"
                        },
                        SocialMetrics: {
                            overview: "Overview",
                            audience: "Audience",
                            engagement: "Engagement",
                            likes: "Likes",
                            comments: "Comments",
                            views: "Views",
                            followers: "Followers",
                            keyAudience: "Key audience",
                            avgEngagementRate: "Avg engagement rate",
                            gender: "Gender",
                            age: "Age",
                            country: "Country",
                            avgLikesPerPost: "Avg likes per post",
                            avgCommentsPerPost: "Avg comments per post",
                            avgViewsPerPost: "Avg views per post"
                        },
                        Bio: {
                            profileAlt: "Profile picture for {{username}}"
                        },
                        Footer: {
                            verified: "Social content verified by Linktree",
                            cookies: "Cookies",
                            privacy: "Privacy",
                            report: "Report"
                        },
                        CaseStudies: {
                            title: "Case studies",
                            resultsHeading: "Results",
                            brandImageAlt: "Brand logo for {{brand}}"
                        }
                    }
                },
                l = {
                    es: {
                        SignupCta: {
                            joinLinkTree: "\xdanete a {{username}} en Linktree",
                            joinLinkTreeToday: "\xdanete a {{username}} hoy en Linktree"
                        },
                        SignupOption: {
                            titleText: "\xdanete a {{username}} en Linktree",
                            subTitleText: "Obt\xe9n tu propio Linktree gratis. El \xfanico enlace en bio en el que conf\xedan m\xe1s de 50 millones de personas.",
                            signupCtaText: "Reg\xedstrate gratis",
                            homePageCtaText: "Descubre m\xe1s"
                        }
                    },
                    pt: {
                        SignupCta: {
                            joinLinkTree: "Junte-se a {{username}} no Linktree",
                            joinLinkTreeToday: "Junte-se a {{username}} hoje no Linktree"
                        },
                        SignupOption: {
                            titleText: "Junte-se a {{username}} no Linktree",
                            subTitleText: "Obtenha seu pr\xf3prio Linktree gratuito. O \xfanico link na bio confi\xe1vel para mais de 50 milh\xf5es de pessoas.",
                            signupCtaText: "Cadastre-se gratuitamente",
                            homePageCtaText: "Saiba mais"
                        }
                    },
                    id: {
                        SignupCta: {
                            joinLinkTree: "Bergabung dengan {{username}} di Linktree",
                            joinLinkTreeToday: "Bergabung dengan {{username}} hari ini di Linktree"
                        },
                        SignupOption: {
                            titleText: "Bergabung dengan {{username}} di Linktree",
                            subTitleText: "Dapatkan Linktree gratis Anda sendiri. Satu-satunya tautan bio yang dipercaya oleh lebih dari 50 juta orang.",
                            signupCtaText: "Daftar gratis",
                            homePageCtaText: "Cari tahu lebih lanjut"
                        }
                    },
                    ar: {
                        SignupCta: {
                            joinLinkTree: "\u0627\u0646\u0636\u0645 \u0625\u0644\u0649 {{username}} \u0639\u0644\u0649 \u0644\u064a\u0646\u0643\u062a\u0631\u064a",
                            joinLinkTreeToday: "\u0627\u0646\u0636\u0645 \u0625\u0644\u0649 {{username}} \u0639\u0644\u0649 \u0644\u064a\u0646\u0643\u062a\u0631\u064a"
                        },
                        SignupOption: {
                            titleText: "\u0627\u0646\u0636\u0645 \u0625\u0644\u0649 {{username}} \u0639\u0644\u0649 Linktree",
                            subTitleText: "\u0627\u062d\u0635\u0644 \u0639\u0644\u0649 Linktree \u0627\u0644\u062e\u0627\u0635 \u0628\u0643 \u0645\u062c\u0627\u0646\u064b\u0627. \u0627\u0644\u0631\u0627\u0628\u0637 \u0627\u0644\u0648\u062d\u064a\u062f \u0641\u064a \u0627\u0644\u0633\u064a\u0631\u0629 \u0627\u0644\u0630\u0627\u062a\u064a\u0629 \u0627\u0644\u0645\u0648\u062b\u0648\u0642 \u0628\u0647 \u0645\u0646 \u0642\u0628\u0644 \u0623\u0643\u062b\u0631 \u0645\u0646 50 \u0645\u0644\u064a\u0648\u0646 \u0634\u062e\u0635.",
                            signupCtaText: "\u0633\u062c\u0644 \u0645\u062c\u0627\u0646\u064b\u0627",
                            homePageCtaText: "\u0627\u0643\u062a\u0634\u0641 \u0627\u0644\u0645\u0632\u064a\u062f"
                        }
                    },
                    fr: {
                        SignupCta: {
                            joinLinkTree: "Rejoignez {{username}} sur Linktree",
                            joinLinkTreeToday: "Rejoignez {{username} sur Linktree aujourd'hui"
                        },
                        SignupOption: {
                            titleText: "Rejoignez {{username}} sur Linktree",
                            subTitleText: "Obtenez votre propre Linktree gratuit. Le seul lien dans la bio auquel plus de 50 millions de personnes font confiance.",
                            signupCtaText: "Inscrivez-vous gratuitement",
                            homePageCtaText: "En savoir plus"
                        }
                    },
                    de: {
                        SignupCta: {
                            joinLinkTree: "Tritt {{username}} auf Linktree bei",
                            joinLinkTreeToday: "Tritt {{username}} auf Linktree bei"
                        },
                        SignupOption: {
                            titleText: "Tritt {{username}} auf Linktree bei",
                            subTitleText: "Hol dir dein eigenes kostenloses Linktree. Der einzige Link in der Bio, dem \xfcber 50 Millionen Menschen vertrauen.",
                            signupCtaText: "Kostenlos registrieren",
                            homePageCtaText: "Mehr erfahren"
                        }
                    },
                    zh: {
                        SignupCta: {
                            joinLinkTree: "\u5728Linktree\u4e0a\u52a0\u5165{{username}}",
                            joinLinkTreeToday: "\u5728Linktree\u4e0a\u52a0\u5165{{username}}"
                        },
                        SignupOption: {
                            titleText: "\u5728Linktree\u4e0a\u52a0\u5165{{username}}",
                            subTitleText: "\u83b7\u53d6\u60a8\u81ea\u5df1\u7684\u514d\u8d39Linktree\u3002\u8d85\u8fc75000\u4e07\u4eba\u4fe1\u8d56\u7684\u552f\u4e00\u4e2a\u4eba\u7b80\u4ecb\u94fe\u63a5\u3002",
                            signupCtaText: "\u514d\u8d39\u6ce8\u518c",
                            homePageCtaText: "\u4e86\u89e3\u66f4\u591a"
                        }
                    },
                    it: {
                        SignupCta: {
                            joinLinkTree: "Unisciti a {{username}} su Linktree",
                            joinLinkTreeToday: "Unisciti a {{username}} su Linktree"
                        },
                        SignupOption: {
                            titleText: "Unisciti a {{username}} su Linktree",
                            subTitleText: "Ottieni il tuo Linktree gratuito. L'unico link in bio di cui si fidano oltre 50 milioni di persone.",
                            signupCtaText: "Registrati gratuitamente",
                            homePageCtaText: "Scopri di pi\xf9"
                        }
                    },
                    ko: {
                        SignupCta: {
                            joinLinkTree: "Linktree\uc5d0\uc11c {{username}}\ub2d8\uacfc \ud568\uaed8\ud558\uc138\uc694",
                            joinLinkTreeToday: "Linktree\uc5d0\uc11c {{username}}\ub2d8\uacfc \ud568\uaed8\ud558\uc138\uc694"
                        },
                        SignupOption: {
                            titleText: "Linktree\uc5d0\uc11c {{username}}\ub2d8\uacfc \ud568\uaed8\ud558\uc138\uc694",
                            subTitleText: "\ubb34\ub8cc\ub85c \ub098\ub9cc\uc758 Linktree\ub97c \ub9cc\ub4e4\uc5b4\ubcf4\uc138\uc694. 5\ucc9c\ub9cc \uba85 \uc774\uc0c1\uc774 \uc2e0\ub8b0\ud558\ub294 \uc720\uc77c\ud55c \ubc14\uc774\uc624 \ub9c1\ud06c\uc785\ub2c8\ub2e4.",
                            signupCtaText: "\ubb34\ub8cc\ub85c \uac00\uc785\ud558\uae30",
                            homePageCtaText: "\ub354 \uc54c\uc544\ubcf4\uae30"
                        }
                    },
                    tr: {
                        SignupCta: {
                            joinLinkTree: "Linktree'de {{username}} ile kat\u0131l\u0131n",
                            joinLinkTreeToday: "Linktree'de {{username}} ile kat\u0131l\u0131n"
                        },
                        SignupOption: {
                            titleText: "Linktree'de {{username}} ile kat\u0131l\u0131n",
                            subTitleText: "Kendi \xfccretsiz Linktree'nizi al\u0131n. 50 milyondan fazla ki\u015finin g\xfcvendi\u011fi tek biyografi ba\u011flant\u0131s\u0131.",
                            signupCtaText: "\xdccretsiz kaydolun",
                            homePageCtaText: "Daha fazla bilgi edinin"
                        }
                    },
                    ru: {
                        SignupCta: {
                            joinLinkTree: "\u041f\u0440\u0438\u0441\u043e\u0435\u0434\u0438\u043d\u044f\u0439\u0442\u0435\u0441\u044c \u043a {{username}} \u043d\u0430 Linktree",
                            joinLinkTreeToday: "\u041f\u0440\u0438\u0441\u043e\u0435\u0434\u0438\u043d\u044f\u0439\u0442\u0435\u0441\u044c \u043a {{username}} \u043d\u0430 Linktree"
                        },
                        SignupOption: {
                            titleText: "\u041f\u0440\u0438\u0441\u043e\u0435\u0434\u0438\u043d\u044f\u0439\u0442\u0435\u0441\u044c \u043a {{username}} \u043d\u0430 Linktree",
                            subTitleText: "\u041f\u043e\u043b\u0443\u0447\u0438\u0442\u0435 \u0441\u0432\u043e\u0439 \u0431\u0435\u0441\u043f\u043b\u0430\u0442\u043d\u044b\u0439 Linktree. \u0415\u0434\u0438\u043d\u0441\u0442\u0432\u0435\u043d\u043d\u0430\u044f \u0441\u0441\u044b\u043b\u043a\u0430 \u0432 \u0431\u0438\u043e, \u043a\u043e\u0442\u043e\u0440\u043e\u0439 \u0434\u043e\u0432\u0435\u0440\u044f\u044e\u0442 \u0431\u043e\u043b\u0435\u0435 50 \u043c\u0438\u043b\u043b\u0438\u043e\u043d\u043e\u0432 \u0447\u0435\u043b\u043e\u0432\u0435\u043a.",
                            signupCtaText: "\u0417\u0430\u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u043e\u0432\u0430\u0442\u044c\u0441\u044f \u0431\u0435\u0441\u043f\u043b\u0430\u0442\u043d\u043e",
                            homePageCtaText: "\u0423\u0437\u043d\u0430\u0442\u044c \u0431\u043e\u043b\u044c\u0448\u0435"
                        }
                    },
                    th: {
                        SignupCta: {
                            joinLinkTree: "\u0e40\u0e02\u0e49\u0e32\u0e23\u0e48\u0e27\u0e21\u0e01\u0e31\u0e1a {{username}} \u0e1a\u0e19 Linktree",
                            joinLinkTreeToday: "\u0e40\u0e02\u0e49\u0e32\u0e23\u0e48\u0e27\u0e21\u0e01\u0e31\u0e1a {{username}} \u0e1a\u0e19 Linktree"
                        },
                        SignupOption: {
                            titleText: "\u0e40\u0e02\u0e49\u0e32\u0e23\u0e48\u0e27\u0e21\u0e01\u0e31\u0e1a {{username}} \u0e1a\u0e19 Linktree",
                            subTitleText: "\u0e23\u0e31\u0e1a Linktree \u0e1f\u0e23\u0e35\u0e02\u0e2d\u0e07\u0e04\u0e38\u0e13\u0e40\u0e2d\u0e07 \u0e40\u0e1b\u0e47\u0e19\u0e25\u0e34\u0e07\u0e01\u0e4c\u0e43\u0e19\u0e1b\u0e23\u0e30\u0e27\u0e31\u0e15\u0e34\u0e40\u0e14\u0e35\u0e22\u0e27\u0e17\u0e35\u0e48\u0e44\u0e14\u0e49\u0e23\u0e31\u0e1a\u0e04\u0e27\u0e32\u0e21\u0e44\u0e27\u0e49\u0e27\u0e32\u0e07\u0e43\u0e08\u0e08\u0e32\u0e01\u0e1c\u0e39\u0e49\u0e04\u0e19\u0e01\u0e27\u0e48\u0e32 50 \u0e25\u0e49\u0e32\u0e19\u0e04\u0e19",
                            signupCtaText: "\u0e2a\u0e21\u0e31\u0e04\u0e23\u0e1f\u0e23\u0e35",
                            homePageCtaText: "\u0e14\u0e39\u0e02\u0e49\u0e2d\u0e21\u0e39\u0e25\u0e40\u0e1e\u0e34\u0e48\u0e21\u0e40\u0e15\u0e34\u0e21"
                        }
                    },
                    nl: {
                        SignupCta: {
                            joinLinkTree: "Doe mee met {{username}} op Linktree",
                            joinLinkTreeToday: "Doe mee met {{username}} op Linktree"
                        },
                        SignupOption: {
                            titleText: "Doe mee met {{username}} op Linktree",
                            subTitleText: "Krijg je eigen gratis Linktree. De enige link in bio die door meer dan 50 miljoen mensen wordt vertrouwd.",
                            signupCtaText: "Gratis aanmelden",
                            homePageCtaText: "Meer informatie"
                        }
                    },
                    ja: {
                        SignupCta: {
                            joinLinkTree: "Linktree\u3067{{username}}\u306b\u53c2\u52a0\u3059\u308b",
                            joinLinkTreeToday: "Linktree\u3067{{username}}\u306b\u53c2\u52a0\u3059\u308b"
                        },
                        SignupOption: {
                            titleText: "Linktree\u3067{{username}}\u306b\u53c2\u52a0\u3059\u308b",
                            subTitleText: "\u7121\u6599\u306eLinktree\u3092\u624b\u306b\u5165\u308c\u3088\u3046\u30025000\u4e07\u4eba\u4ee5\u4e0a\u304c\u4fe1\u983c\u3059\u308b\u552f\u4e00\u306e\u30d0\u30a4\u30aa\u30ea\u30f3\u30af\u3002",
                            signupCtaText: "\u7121\u6599\u3067\u767b\u9332",
                            homePageCtaText: "\u8a73\u7d30\u3092\u898b\u308b"
                        }
                    },
                    vi: {
                        SignupCta: {
                            joinLinkTree: "Tham gia c\xf9ng {{username}} tr\xean Linktree",
                            joinLinkTreeToday: "Tham gia c\xf9ng {{username}} tr\xean Linktree"
                        },
                        SignupOption: {
                            titleText: "Tham gia c\xf9ng {{username}} tr\xean Linktree",
                            subTitleText: "Nh\u1eadn Linktree mi\u1ec5n ph\xed c\u1ee7a ri\xeang b\u1ea1n. Li\xean k\u1ebft trong ti\u1ec3u s\u1eed duy nh\u1ea5t \u0111\u01b0\u1ee3c tin t\u01b0\u1edfng b\u1edfi h\u01a1n 50 tri\u1ec7u ng\u01b0\u1eddi.",
                            signupCtaText: "\u0110\u0103ng k\xfd mi\u1ec5n ph\xed",
                            homePageCtaText: "T\xecm hi\u1ec3u th\xeam"
                        }
                    }
                };

            function u(e, t) {
                var i = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(e);
                    t && (n = n.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), i.push.apply(i, n)
                }
                return i
            }

            function c(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var i = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? u(Object(i), !0).forEach((function(t) {
                        (0, a.Z)(e, t, i[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(i)) : u(Object(i)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(i, t))
                    }))
                }
                return e
            }
            var d = e => {
                    let {
                        defaultVariables: t
                    } = e;
                    return r.Z.createInstance({
                        resources: c({
                            en: s
                        }, l),
                        lng: "en",
                        fallbackLng: "en",
                        interpolation: {
                            defaultVariables: t,
                            escapeValue: !1
                        }
                    }, (e => {
                        if (e) return console.log("something went wrong loading i18n", e)
                    }))
                },
                m = i(85893);
            var p = e => {
                let {
                    global: t,
                    children: i
                } = e;
                return (0, m.jsx)(n.a3, {
                    i18n: d({
                        defaultVariables: t
                    }),
                    children: i
                })
            }
        }
    }
]);