(self.__LOADABLE_LOADED_CHUNKS__ = self.__LOADABLE_LOADED_CHUNKS__ || []).push([
    [3073], {
        58975: function(_, n, u) {
            (window.__NEXT_P = window.__NEXT_P || []).push(["/[profile]", function() {
                return u(39036)
            }])
        }
    },
    function(_) {
        _.O(0, [4301, 236, 8858, 9036, 9774, 2888, 179], (function() {
            return n = 58975, _(_.s = n);
            var n
        }));
        var n = _.O();
        _N_E = n
    }
]);