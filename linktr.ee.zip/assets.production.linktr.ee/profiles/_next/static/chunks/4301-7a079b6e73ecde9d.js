"use strict";
(self.__LOADABLE_LOADED_CHUNKS__ = self.__LOADABLE_LOADED_CHUNKS__ || []).push([
    [4301], {
        44301: function(e, t, n) {
            n.d(t, {
                Z: function() {
                    return W
                }
            });
            var i = n(71002),
                o = n(83997);

            function r(e, t, n) {
                return (t = (0, o.Z)(t)) in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e
            }

            function a(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? Object(arguments[t]) : {},
                        i = Object.keys(n);
                    "function" === typeof Object.getOwnPropertySymbols && i.push.apply(i, Object.getOwnPropertySymbols(n).filter((function(e) {
                        return Object.getOwnPropertyDescriptor(n, e).enumerable
                    }))), i.forEach((function(t) {
                        r(e, t, n[t])
                    }))
                }
                return e
            }

            function s(e, t) {
                if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
            }
            var u = n(43144),
                l = n(97326);

            function c(e, t) {
                if (t && ("object" === (0, i.Z)(t) || "function" === typeof t)) return t;
                if (void 0 !== t) throw new TypeError("Derived constructors may only return object or undefined");
                return (0, l.Z)(e)
            }
            var p = n(61120),
                g = n(89611);

            function f(e, t) {
                if ("function" !== typeof t && null !== t) throw new TypeError("Super expression must either be null or a function");
                e.prototype = Object.create(t && t.prototype, {
                    constructor: {
                        value: e,
                        writable: !0,
                        configurable: !0
                    }
                }), Object.defineProperty(e, "prototype", {
                    writable: !1
                }), t && (0, g.Z)(e, t)
            }
            var h = {
                    type: "logger",
                    log: function(e) {
                        this.output("log", e)
                    },
                    warn: function(e) {
                        this.output("warn", e)
                    },
                    error: function(e) {
                        this.output("error", e)
                    },
                    output: function(e, t) {
                        console && console[e] && console[e].apply(console, t)
                    }
                },
                d = function() {
                    function e(t) {
                        var n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                        s(this, e), this.init(t, n)
                    }
                    return (0, u.Z)(e, [{
                        key: "init",
                        value: function(e) {
                            var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                            this.prefix = t.prefix || "i18next:", this.logger = e || h, this.options = t, this.debug = t.debug
                        }
                    }, {
                        key: "setDebug",
                        value: function(e) {
                            this.debug = e
                        }
                    }, {
                        key: "log",
                        value: function() {
                            for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++) t[n] = arguments[n];
                            return this.forward(t, "log", "", !0)
                        }
                    }, {
                        key: "warn",
                        value: function() {
                            for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++) t[n] = arguments[n];
                            return this.forward(t, "warn", "", !0)
                        }
                    }, {
                        key: "error",
                        value: function() {
                            for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++) t[n] = arguments[n];
                            return this.forward(t, "error", "")
                        }
                    }, {
                        key: "deprecate",
                        value: function() {
                            for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++) t[n] = arguments[n];
                            return this.forward(t, "warn", "WARNING DEPRECATED: ", !0)
                        }
                    }, {
                        key: "forward",
                        value: function(e, t, n, i) {
                            return i && !this.debug ? null : ("string" === typeof e[0] && (e[0] = "".concat(n).concat(this.prefix, " ").concat(e[0])), this.logger[t](e))
                        }
                    }, {
                        key: "create",
                        value: function(t) {
                            return new e(this.logger, a({}, {
                                prefix: "".concat(this.prefix, ":").concat(t, ":")
                            }, this.options))
                        }
                    }]), e
                }(),
                v = new d,
                y = function() {
                    function e() {
                        s(this, e), this.observers = {}
                    }
                    return (0, u.Z)(e, [{
                        key: "on",
                        value: function(e, t) {
                            var n = this;
                            return e.split(" ").forEach((function(e) {
                                n.observers[e] = n.observers[e] || [], n.observers[e].push(t)
                            })), this
                        }
                    }, {
                        key: "off",
                        value: function(e, t) {
                            this.observers[e] && (t ? this.observers[e] = this.observers[e].filter((function(e) {
                                return e !== t
                            })) : delete this.observers[e])
                        }
                    }, {
                        key: "emit",
                        value: function(e) {
                            for (var t = arguments.length, n = new Array(t > 1 ? t - 1 : 0), i = 1; i < t; i++) n[i - 1] = arguments[i];
                            if (this.observers[e]) {
                                var o = [].concat(this.observers[e]);
                                o.forEach((function(e) {
                                    e.apply(void 0, n)
                                }))
                            }
                            if (this.observers["*"]) {
                                var r = [].concat(this.observers["*"]);
                                r.forEach((function(t) {
                                    t.apply(t, [e].concat(n))
                                }))
                            }
                        }
                    }]), e
                }();

            function m() {
                var e, t, n = new Promise((function(n, i) {
                    e = n, t = i
                }));
                return n.resolve = e, n.reject = t, n
            }

            function b(e) {
                return null == e ? "" : "" + e
            }

            function k(e, t, n) {
                e.forEach((function(e) {
                    t[e] && (n[e] = t[e])
                }))
            }

            function x(e, t, n) {
                function i(e) {
                    return e && e.indexOf("###") > -1 ? e.replace(/###/g, ".") : e
                }

                function o() {
                    return !e || "string" === typeof e
                }
                for (var r = "string" !== typeof t ? [].concat(t) : t.split("."); r.length > 1;) {
                    if (o()) return {};
                    var a = i(r.shift());
                    !e[a] && n && (e[a] = new n), e = Object.prototype.hasOwnProperty.call(e, a) ? e[a] : {}
                }
                return o() ? {} : {
                    obj: e,
                    k: i(r.shift())
                }
            }

            function w(e, t, n) {
                var i = x(e, t, Object);
                i.obj[i.k] = n
            }

            function S(e, t) {
                var n = x(e, t),
                    i = n.obj,
                    o = n.k;
                if (i) return i[o]
            }

            function L(e, t, n) {
                var i = S(e, n);
                return void 0 !== i ? i : S(t, n)
            }

            function O(e, t, n) {
                for (var i in t) "__proto__" !== i && "constructor" !== i && (i in e ? "string" === typeof e[i] || e[i] instanceof String || "string" === typeof t[i] || t[i] instanceof String ? n && (e[i] = t[i]) : O(e[i], t[i], n) : e[i] = t[i]);
                return e
            }

            function C(e) {
                return e.replace(/[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g, "\\$&")
            }
            var R = {
                "&": "&amp;",
                "<": "&lt;",
                ">": "&gt;",
                '"': "&quot;",
                "'": "&#39;",
                "/": "&#x2F;"
            };

            function N(e) {
                return "string" === typeof e ? e.replace(/[&<>"'\/]/g, (function(e) {
                    return R[e]
                })) : e
            }
            var j = "undefined" !== typeof window && window.navigator && window.navigator.userAgent && window.navigator.userAgent.indexOf("MSIE") > -1,
                E = function(e) {
                    function t(e) {
                        var n, i = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {
                            ns: ["translation"],
                            defaultNS: "translation"
                        };
                        return s(this, t), n = c(this, (0, p.Z)(t).call(this)), j && y.call((0, l.Z)(n)), n.data = e || {}, n.options = i, void 0 === n.options.keySeparator && (n.options.keySeparator = "."), n
                    }
                    return f(t, e), (0, u.Z)(t, [{
                        key: "addNamespaces",
                        value: function(e) {
                            this.options.ns.indexOf(e) < 0 && this.options.ns.push(e)
                        }
                    }, {
                        key: "removeNamespaces",
                        value: function(e) {
                            var t = this.options.ns.indexOf(e);
                            t > -1 && this.options.ns.splice(t, 1)
                        }
                    }, {
                        key: "getResource",
                        value: function(e, t, n) {
                            var i = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : {},
                                o = void 0 !== i.keySeparator ? i.keySeparator : this.options.keySeparator,
                                r = [e, t];
                            return n && "string" !== typeof n && (r = r.concat(n)), n && "string" === typeof n && (r = r.concat(o ? n.split(o) : n)), e.indexOf(".") > -1 && (r = e.split(".")), S(this.data, r)
                        }
                    }, {
                        key: "addResource",
                        value: function(e, t, n, i) {
                            var o = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : {
                                    silent: !1
                                },
                                r = this.options.keySeparator;
                            void 0 === r && (r = ".");
                            var a = [e, t];
                            n && (a = a.concat(r ? n.split(r) : n)), e.indexOf(".") > -1 && (i = t, t = (a = e.split("."))[1]), this.addNamespaces(t), w(this.data, a, i), o.silent || this.emit("added", e, t, n, i)
                        }
                    }, {
                        key: "addResources",
                        value: function(e, t, n) {
                            var i = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : {
                                silent: !1
                            };
                            for (var o in n) "string" !== typeof n[o] && "[object Array]" !== Object.prototype.toString.apply(n[o]) || this.addResource(e, t, o, n[o], {
                                silent: !0
                            });
                            i.silent || this.emit("added", e, t, n)
                        }
                    }, {
                        key: "addResourceBundle",
                        value: function(e, t, n, i, o) {
                            var r = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : {
                                    silent: !1
                                },
                                s = [e, t];
                            e.indexOf(".") > -1 && (i = n, n = t, t = (s = e.split("."))[1]), this.addNamespaces(t);
                            var u = S(this.data, s) || {};
                            i ? O(u, n, o) : u = a({}, u, n), w(this.data, s, u), r.silent || this.emit("added", e, t, n)
                        }
                    }, {
                        key: "removeResourceBundle",
                        value: function(e, t) {
                            this.hasResourceBundle(e, t) && delete this.data[e][t], this.removeNamespaces(t), this.emit("removed", e, t)
                        }
                    }, {
                        key: "hasResourceBundle",
                        value: function(e, t) {
                            return void 0 !== this.getResource(e, t)
                        }
                    }, {
                        key: "getResourceBundle",
                        value: function(e, t) {
                            return t || (t = this.options.defaultNS), "v1" === this.options.compatibilityAPI ? a({}, {}, this.getResource(e, t)) : this.getResource(e, t)
                        }
                    }, {
                        key: "getDataByLanguage",
                        value: function(e) {
                            return this.data[e]
                        }
                    }, {
                        key: "toJSON",
                        value: function() {
                            return this.data
                        }
                    }]), t
                }(y),
                P = {
                    processors: {},
                    addPostProcessor: function(e) {
                        this.processors[e.name] = e
                    },
                    handle: function(e, t, n, i, o) {
                        var r = this;
                        return e.forEach((function(e) {
                            r.processors[e] && (t = r.processors[e].process(t, n, i, o))
                        })), t
                    }
                },
                F = {},
                A = function(e) {
                    function t(e) {
                        var n, i = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                        return s(this, t), n = c(this, (0, p.Z)(t).call(this)), j && y.call((0, l.Z)(n)), k(["resourceStore", "languageUtils", "pluralResolver", "interpolator", "backendConnector", "i18nFormat", "utils"], e, (0, l.Z)(n)), n.options = i, void 0 === n.options.keySeparator && (n.options.keySeparator = "."), n.logger = v.create("translator"), n
                    }
                    return f(t, e), (0, u.Z)(t, [{
                        key: "changeLanguage",
                        value: function(e) {
                            e && (this.language = e)
                        }
                    }, {
                        key: "exists",
                        value: function(e) {
                            var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {
                                    interpolation: {}
                                },
                                n = this.resolve(e, t);
                            return n && void 0 !== n.res
                        }
                    }, {
                        key: "extractFromKey",
                        value: function(e, t) {
                            var n = void 0 !== t.nsSeparator ? t.nsSeparator : this.options.nsSeparator;
                            void 0 === n && (n = ":");
                            var i = void 0 !== t.keySeparator ? t.keySeparator : this.options.keySeparator,
                                o = t.ns || this.options.defaultNS;
                            if (n && e.indexOf(n) > -1) {
                                var r = e.match(this.interpolator.nestingRegexp);
                                if (r && r.length > 0) return {
                                    key: e,
                                    namespaces: o
                                };
                                var a = e.split(n);
                                (n !== i || n === i && this.options.ns.indexOf(a[0]) > -1) && (o = a.shift()), e = a.join(i)
                            }
                            return "string" === typeof o && (o = [o]), {
                                key: e,
                                namespaces: o
                            }
                        }
                    }, {
                        key: "translate",
                        value: function(e, n, o) {
                            var r = this;
                            if ("object" !== (0, i.Z)(n) && this.options.overloadTranslationOptionHandler && (n = this.options.overloadTranslationOptionHandler(arguments)), n || (n = {}), void 0 === e || null === e) return "";
                            Array.isArray(e) || (e = [String(e)]);
                            var s = void 0 !== n.keySeparator ? n.keySeparator : this.options.keySeparator,
                                u = this.extractFromKey(e[e.length - 1], n),
                                l = u.key,
                                c = u.namespaces,
                                p = c[c.length - 1],
                                g = n.lng || this.language,
                                f = n.appendNamespaceToCIMode || this.options.appendNamespaceToCIMode;
                            if (g && "cimode" === g.toLowerCase()) {
                                if (f) {
                                    var h = n.nsSeparator || this.options.nsSeparator;
                                    return p + h + l
                                }
                                return l
                            }
                            var d = this.resolve(e, n),
                                v = d && d.res,
                                y = d && d.usedKey || l,
                                m = d && d.exactUsedKey || l,
                                b = Object.prototype.toString.apply(v),
                                k = ["[object Number]", "[object Function]", "[object RegExp]"],
                                x = void 0 !== n.joinArrays ? n.joinArrays : this.options.joinArrays,
                                w = !this.i18nFormat || this.i18nFormat.handleAsObject,
                                S = "string" !== typeof v && "boolean" !== typeof v && "number" !== typeof v;
                            if (w && v && S && k.indexOf(b) < 0 && ("string" !== typeof x || "[object Array]" !== b)) {
                                if (!n.returnObjects && !this.options.returnObjects) return this.logger.warn("accessing an object - but returnObjects options is not enabled!"), this.options.returnedObjectHandler ? this.options.returnedObjectHandler(y, v, n) : "key '".concat(l, " (").concat(this.language, ")' returned an object instead of string.");
                                if (s) {
                                    var L = "[object Array]" === b,
                                        O = L ? [] : {},
                                        C = L ? m : y;
                                    for (var R in v)
                                        if (Object.prototype.hasOwnProperty.call(v, R)) {
                                            var N = "".concat(C).concat(s).concat(R);
                                            O[R] = this.translate(N, a({}, n, {
                                                joinArrays: !1,
                                                ns: c
                                            })), O[R] === N && (O[R] = v[R])
                                        }
                                    v = O
                                }
                            } else if (w && "string" === typeof x && "[object Array]" === b)(v = v.join(x)) && (v = this.extendTranslation(v, e, n, o));
                            else {
                                var j = !1,
                                    E = !1,
                                    P = void 0 !== n.count && "string" !== typeof n.count,
                                    F = t.hasDefaultValue(n),
                                    A = P ? this.pluralResolver.getSuffix(g, n.count) : "",
                                    V = n["defaultValue".concat(A)] || n.defaultValue;
                                !this.isValidLookup(v) && F && (j = !0, v = V), this.isValidLookup(v) || (E = !0, v = l);
                                var Z = F && V !== v && this.options.updateMissing;
                                if (E || j || Z) {
                                    if (this.logger.log(Z ? "updateKey" : "missingKey", g, p, l, Z ? V : v), s) {
                                        var D = this.resolve(l, a({}, n, {
                                            keySeparator: !1
                                        }));
                                        D && D.res && this.logger.warn("Seems the loaded translations were in flat JSON format instead of nested. Either set keySeparator: false on init or make sure your translations are published in nested format.")
                                    }
                                    var T = [],
                                        U = this.languageUtils.getFallbackCodes(this.options.fallbackLng, n.lng || this.language);
                                    if ("fallback" === this.options.saveMissingTo && U && U[0])
                                        for (var I = 0; I < U.length; I++) T.push(U[I]);
                                    else "all" === this.options.saveMissingTo ? T = this.languageUtils.toResolveHierarchy(n.lng || this.language) : T.push(n.lng || this.language);
                                    var H = function(e, t, i) {
                                        r.options.missingKeyHandler ? r.options.missingKeyHandler(e, p, t, Z ? i : v, Z, n) : r.backendConnector && r.backendConnector.saveMissing && r.backendConnector.saveMissing(e, p, t, Z ? i : v, Z, n), r.emit("missingKey", e, p, t, v)
                                    };
                                    this.options.saveMissing && (this.options.saveMissingPlurals && P ? T.forEach((function(e) {
                                        r.pluralResolver.getSuffixes(e).forEach((function(t) {
                                            H([e], l + t, n["defaultValue".concat(t)] || V)
                                        }))
                                    })) : H(T, l, V))
                                }
                                v = this.extendTranslation(v, e, n, d, o), E && v === l && this.options.appendNamespaceToMissingKey && (v = "".concat(p, ":").concat(l)), E && this.options.parseMissingKeyHandler && (v = this.options.parseMissingKeyHandler(v))
                            }
                            return v
                        }
                    }, {
                        key: "extendTranslation",
                        value: function(e, t, n, i, o) {
                            var r = this;
                            if (this.i18nFormat && this.i18nFormat.parse) e = this.i18nFormat.parse(e, n, i.usedLng, i.usedNS, i.usedKey, {
                                resolved: i
                            });
                            else if (!n.skipInterpolation) {
                                n.interpolation && this.interpolator.init(a({}, n, {
                                    interpolation: a({}, this.options.interpolation, n.interpolation)
                                }));
                                var s, u = n.interpolation && n.interpolation.skipOnVariables || this.options.interpolation.skipOnVariables;
                                if (u) {
                                    var l = e.match(this.interpolator.nestingRegexp);
                                    s = l && l.length
                                }
                                var c = n.replace && "string" !== typeof n.replace ? n.replace : n;
                                if (this.options.interpolation.defaultVariables && (c = a({}, this.options.interpolation.defaultVariables, c)), e = this.interpolator.interpolate(e, c, n.lng || this.language, n), u) {
                                    var p = e.match(this.interpolator.nestingRegexp);
                                    s < (p && p.length) && (n.nest = !1)
                                }!1 !== n.nest && (e = this.interpolator.nest(e, (function() {
                                    for (var e = arguments.length, i = new Array(e), a = 0; a < e; a++) i[a] = arguments[a];
                                    return o && o[0] === i[0] && !n.context ? (r.logger.warn("It seems you are nesting recursively key: ".concat(i[0], " in key: ").concat(t[0])), null) : r.translate.apply(r, i.concat([t]))
                                }), n)), n.interpolation && this.interpolator.reset()
                            }
                            var g = n.postProcess || this.options.postProcess,
                                f = "string" === typeof g ? [g] : g;
                            return void 0 !== e && null !== e && f && f.length && !1 !== n.applyPostProcessor && (e = P.handle(f, e, t, this.options && this.options.postProcessPassResolved ? a({
                                i18nResolved: i
                            }, n) : n, this)), e
                        }
                    }, {
                        key: "resolve",
                        value: function(e) {
                            var t, n, i, o, r, a = this,
                                s = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                            return "string" === typeof e && (e = [e]), e.forEach((function(e) {
                                if (!a.isValidLookup(t)) {
                                    var u = a.extractFromKey(e, s),
                                        l = u.key;
                                    n = l;
                                    var c = u.namespaces;
                                    a.options.fallbackNS && (c = c.concat(a.options.fallbackNS));
                                    var p = void 0 !== s.count && "string" !== typeof s.count,
                                        g = void 0 !== s.context && "string" === typeof s.context && "" !== s.context,
                                        f = s.lngs ? s.lngs : a.languageUtils.toResolveHierarchy(s.lng || a.language, s.fallbackLng);
                                    c.forEach((function(e) {
                                        a.isValidLookup(t) || (r = e, !F["".concat(f[0], "-").concat(e)] && a.utils && a.utils.hasLoadedNamespace && !a.utils.hasLoadedNamespace(r) && (F["".concat(f[0], "-").concat(e)] = !0, a.logger.warn('key "'.concat(n, '" for languages "').concat(f.join(", "), '" won\'t get resolved as namespace "').concat(r, '" was not yet loaded'), "This means something IS WRONG in your setup. You access the t function before i18next.init / i18next.loadNamespace / i18next.changeLanguage was done. Wait for the callback or Promise to resolve before accessing it!!!")), f.forEach((function(n) {
                                            if (!a.isValidLookup(t)) {
                                                o = n;
                                                var r, u, c = l,
                                                    f = [c];
                                                if (a.i18nFormat && a.i18nFormat.addLookupKeys) a.i18nFormat.addLookupKeys(f, l, n, e, s);
                                                else p && (r = a.pluralResolver.getSuffix(n, s.count)), p && g && f.push(c + r), g && f.push(c += "".concat(a.options.contextSeparator).concat(s.context)), p && f.push(c += r);
                                                for (; u = f.pop();) a.isValidLookup(t) || (i = u, t = a.getResource(n, e, u, s))
                                            }
                                        })))
                                    }))
                                }
                            })), {
                                res: t,
                                usedKey: n,
                                exactUsedKey: i,
                                usedLng: o,
                                usedNS: r
                            }
                        }
                    }, {
                        key: "isValidLookup",
                        value: function(e) {
                            return void 0 !== e && !(!this.options.returnNull && null === e) && !(!this.options.returnEmptyString && "" === e)
                        }
                    }, {
                        key: "getResource",
                        value: function(e, t, n) {
                            var i = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : {};
                            return this.i18nFormat && this.i18nFormat.getResource ? this.i18nFormat.getResource(e, t, n, i) : this.resourceStore.getResource(e, t, n, i)
                        }
                    }], [{
                        key: "hasDefaultValue",
                        value: function(e) {
                            var t = "defaultValue";
                            for (var n in e)
                                if (Object.prototype.hasOwnProperty.call(e, n) && t === n.substring(0, t.length) && void 0 !== e[n]) return !0;
                            return !1
                        }
                    }]), t
                }(y);

            function V(e) {
                return e.charAt(0).toUpperCase() + e.slice(1)
            }
            var Z = function() {
                    function e(t) {
                        s(this, e), this.options = t, this.whitelist = this.options.supportedLngs || !1, this.supportedLngs = this.options.supportedLngs || !1, this.logger = v.create("languageUtils")
                    }
                    return (0, u.Z)(e, [{
                        key: "getScriptPartFromCode",
                        value: function(e) {
                            if (!e || e.indexOf("-") < 0) return null;
                            var t = e.split("-");
                            return 2 === t.length ? null : (t.pop(), "x" === t[t.length - 1].toLowerCase() ? null : this.formatLanguageCode(t.join("-")))
                        }
                    }, {
                        key: "getLanguagePartFromCode",
                        value: function(e) {
                            if (!e || e.indexOf("-") < 0) return e;
                            var t = e.split("-");
                            return this.formatLanguageCode(t[0])
                        }
                    }, {
                        key: "formatLanguageCode",
                        value: function(e) {
                            if ("string" === typeof e && e.indexOf("-") > -1) {
                                var t = ["hans", "hant", "latn", "cyrl", "cans", "mong", "arab"],
                                    n = e.split("-");
                                return this.options.lowerCaseLng ? n = n.map((function(e) {
                                    return e.toLowerCase()
                                })) : 2 === n.length ? (n[0] = n[0].toLowerCase(), n[1] = n[1].toUpperCase(), t.indexOf(n[1].toLowerCase()) > -1 && (n[1] = V(n[1].toLowerCase()))) : 3 === n.length && (n[0] = n[0].toLowerCase(), 2 === n[1].length && (n[1] = n[1].toUpperCase()), "sgn" !== n[0] && 2 === n[2].length && (n[2] = n[2].toUpperCase()), t.indexOf(n[1].toLowerCase()) > -1 && (n[1] = V(n[1].toLowerCase())), t.indexOf(n[2].toLowerCase()) > -1 && (n[2] = V(n[2].toLowerCase()))), n.join("-")
                            }
                            return this.options.cleanCode || this.options.lowerCaseLng ? e.toLowerCase() : e
                        }
                    }, {
                        key: "isWhitelisted",
                        value: function(e) {
                            return this.logger.deprecate("languageUtils.isWhitelisted", 'function "isWhitelisted" will be renamed to "isSupportedCode" in the next major - please make sure to rename it\'s usage asap.'), this.isSupportedCode(e)
                        }
                    }, {
                        key: "isSupportedCode",
                        value: function(e) {
                            return ("languageOnly" === this.options.load || this.options.nonExplicitSupportedLngs) && (e = this.getLanguagePartFromCode(e)), !this.supportedLngs || !this.supportedLngs.length || this.supportedLngs.indexOf(e) > -1
                        }
                    }, {
                        key: "getBestMatchFromCodes",
                        value: function(e) {
                            var t, n = this;
                            return e ? (e.forEach((function(e) {
                                if (!t) {
                                    var i = n.formatLanguageCode(e);
                                    n.options.supportedLngs && !n.isSupportedCode(i) || (t = i)
                                }
                            })), !t && this.options.supportedLngs && e.forEach((function(e) {
                                if (!t) {
                                    var i = n.getLanguagePartFromCode(e);
                                    if (n.isSupportedCode(i)) return t = i;
                                    t = n.options.supportedLngs.find((function(e) {
                                        if (0 === e.indexOf(i)) return e
                                    }))
                                }
                            })), t || (t = this.getFallbackCodes(this.options.fallbackLng)[0]), t) : null
                        }
                    }, {
                        key: "getFallbackCodes",
                        value: function(e, t) {
                            if (!e) return [];
                            if ("function" === typeof e && (e = e(t)), "string" === typeof e && (e = [e]), "[object Array]" === Object.prototype.toString.apply(e)) return e;
                            if (!t) return e.default || [];
                            var n = e[t];
                            return n || (n = e[this.getScriptPartFromCode(t)]), n || (n = e[this.formatLanguageCode(t)]), n || (n = e[this.getLanguagePartFromCode(t)]), n || (n = e.default), n || []
                        }
                    }, {
                        key: "toResolveHierarchy",
                        value: function(e, t) {
                            var n = this,
                                i = this.getFallbackCodes(t || this.options.fallbackLng || [], e),
                                o = [],
                                r = function(e) {
                                    e && (n.isSupportedCode(e) ? o.push(e) : n.logger.warn("rejecting language code not found in supportedLngs: ".concat(e)))
                                };
                            return "string" === typeof e && e.indexOf("-") > -1 ? ("languageOnly" !== this.options.load && r(this.formatLanguageCode(e)), "languageOnly" !== this.options.load && "currentOnly" !== this.options.load && r(this.getScriptPartFromCode(e)), "currentOnly" !== this.options.load && r(this.getLanguagePartFromCode(e))) : "string" === typeof e && r(this.formatLanguageCode(e)), i.forEach((function(e) {
                                o.indexOf(e) < 0 && r(n.formatLanguageCode(e))
                            })), o
                        }
                    }]), e
                }(),
                D = [{
                    lngs: ["ach", "ak", "am", "arn", "br", "fil", "gun", "ln", "mfe", "mg", "mi", "oc", "pt", "pt-BR", "tg", "tl", "ti", "tr", "uz", "wa"],
                    nr: [1, 2],
                    fc: 1
                }, {
                    lngs: ["af", "an", "ast", "az", "bg", "bn", "ca", "da", "de", "dev", "el", "en", "eo", "es", "et", "eu", "fi", "fo", "fur", "fy", "gl", "gu", "ha", "hi", "hu", "hy", "ia", "it", "kn", "ku", "lb", "mai", "ml", "mn", "mr", "nah", "nap", "nb", "ne", "nl", "nn", "no", "nso", "pa", "pap", "pms", "ps", "pt-PT", "rm", "sco", "se", "si", "so", "son", "sq", "sv", "sw", "ta", "te", "tk", "ur", "yo"],
                    nr: [1, 2],
                    fc: 2
                }, {
                    lngs: ["ay", "bo", "cgg", "fa", "ht", "id", "ja", "jbo", "ka", "kk", "km", "ko", "ky", "lo", "ms", "sah", "su", "th", "tt", "ug", "vi", "wo", "zh"],
                    nr: [1],
                    fc: 3
                }, {
                    lngs: ["be", "bs", "cnr", "dz", "hr", "ru", "sr", "uk"],
                    nr: [1, 2, 5],
                    fc: 4
                }, {
                    lngs: ["ar"],
                    nr: [0, 1, 2, 3, 11, 100],
                    fc: 5
                }, {
                    lngs: ["cs", "sk"],
                    nr: [1, 2, 5],
                    fc: 6
                }, {
                    lngs: ["csb", "pl"],
                    nr: [1, 2, 5],
                    fc: 7
                }, {
                    lngs: ["cy"],
                    nr: [1, 2, 3, 8],
                    fc: 8
                }, {
                    lngs: ["fr"],
                    nr: [1, 2],
                    fc: 9
                }, {
                    lngs: ["ga"],
                    nr: [1, 2, 3, 7, 11],
                    fc: 10
                }, {
                    lngs: ["gd"],
                    nr: [1, 2, 3, 20],
                    fc: 11
                }, {
                    lngs: ["is"],
                    nr: [1, 2],
                    fc: 12
                }, {
                    lngs: ["jv"],
                    nr: [0, 1],
                    fc: 13
                }, {
                    lngs: ["kw"],
                    nr: [1, 2, 3, 4],
                    fc: 14
                }, {
                    lngs: ["lt"],
                    nr: [1, 2, 10],
                    fc: 15
                }, {
                    lngs: ["lv"],
                    nr: [1, 2, 0],
                    fc: 16
                }, {
                    lngs: ["mk"],
                    nr: [1, 2],
                    fc: 17
                }, {
                    lngs: ["mnk"],
                    nr: [0, 1, 2],
                    fc: 18
                }, {
                    lngs: ["mt"],
                    nr: [1, 2, 11, 20],
                    fc: 19
                }, {
                    lngs: ["or"],
                    nr: [2, 1],
                    fc: 2
                }, {
                    lngs: ["ro"],
                    nr: [1, 2, 20],
                    fc: 20
                }, {
                    lngs: ["sl"],
                    nr: [5, 1, 2, 3],
                    fc: 21
                }, {
                    lngs: ["he", "iw"],
                    nr: [1, 2, 20, 21],
                    fc: 22
                }],
                T = {
                    1: function(e) {
                        return Number(e > 1)
                    },
                    2: function(e) {
                        return Number(1 != e)
                    },
                    3: function(e) {
                        return 0
                    },
                    4: function(e) {
                        return Number(e % 10 == 1 && e % 100 != 11 ? 0 : e % 10 >= 2 && e % 10 <= 4 && (e % 100 < 10 || e % 100 >= 20) ? 1 : 2)
                    },
                    5: function(e) {
                        return Number(0 == e ? 0 : 1 == e ? 1 : 2 == e ? 2 : e % 100 >= 3 && e % 100 <= 10 ? 3 : e % 100 >= 11 ? 4 : 5)
                    },
                    6: function(e) {
                        return Number(1 == e ? 0 : e >= 2 && e <= 4 ? 1 : 2)
                    },
                    7: function(e) {
                        return Number(1 == e ? 0 : e % 10 >= 2 && e % 10 <= 4 && (e % 100 < 10 || e % 100 >= 20) ? 1 : 2)
                    },
                    8: function(e) {
                        return Number(1 == e ? 0 : 2 == e ? 1 : 8 != e && 11 != e ? 2 : 3)
                    },
                    9: function(e) {
                        return Number(e >= 2)
                    },
                    10: function(e) {
                        return Number(1 == e ? 0 : 2 == e ? 1 : e < 7 ? 2 : e < 11 ? 3 : 4)
                    },
                    11: function(e) {
                        return Number(1 == e || 11 == e ? 0 : 2 == e || 12 == e ? 1 : e > 2 && e < 20 ? 2 : 3)
                    },
                    12: function(e) {
                        return Number(e % 10 != 1 || e % 100 == 11)
                    },
                    13: function(e) {
                        return Number(0 !== e)
                    },
                    14: function(e) {
                        return Number(1 == e ? 0 : 2 == e ? 1 : 3 == e ? 2 : 3)
                    },
                    15: function(e) {
                        return Number(e % 10 == 1 && e % 100 != 11 ? 0 : e % 10 >= 2 && (e % 100 < 10 || e % 100 >= 20) ? 1 : 2)
                    },
                    16: function(e) {
                        return Number(e % 10 == 1 && e % 100 != 11 ? 0 : 0 !== e ? 1 : 2)
                    },
                    17: function(e) {
                        return Number(1 == e || e % 10 == 1 && e % 100 != 11 ? 0 : 1)
                    },
                    18: function(e) {
                        return Number(0 == e ? 0 : 1 == e ? 1 : 2)
                    },
                    19: function(e) {
                        return Number(1 == e ? 0 : 0 == e || e % 100 > 1 && e % 100 < 11 ? 1 : e % 100 > 10 && e % 100 < 20 ? 2 : 3)
                    },
                    20: function(e) {
                        return Number(1 == e ? 0 : 0 == e || e % 100 > 0 && e % 100 < 20 ? 1 : 2)
                    },
                    21: function(e) {
                        return Number(e % 100 == 1 ? 1 : e % 100 == 2 ? 2 : e % 100 == 3 || e % 100 == 4 ? 3 : 0)
                    },
                    22: function(e) {
                        return Number(1 == e ? 0 : 2 == e ? 1 : (e < 0 || e > 10) && e % 10 == 0 ? 2 : 3)
                    }
                };

            function U() {
                var e = {};
                return D.forEach((function(t) {
                    t.lngs.forEach((function(n) {
                        e[n] = {
                            numbers: t.nr,
                            plurals: T[t.fc]
                        }
                    }))
                })), e
            }
            var I = function() {
                    function e(t) {
                        var n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                        s(this, e), this.languageUtils = t, this.options = n, this.logger = v.create("pluralResolver"), this.rules = U()
                    }
                    return (0, u.Z)(e, [{
                        key: "addRule",
                        value: function(e, t) {
                            this.rules[e] = t
                        }
                    }, {
                        key: "getRule",
                        value: function(e) {
                            return this.rules[e] || this.rules[this.languageUtils.getLanguagePartFromCode(e)]
                        }
                    }, {
                        key: "needsPlural",
                        value: function(e) {
                            var t = this.getRule(e);
                            return t && t.numbers.length > 1
                        }
                    }, {
                        key: "getPluralFormsOfKey",
                        value: function(e, t) {
                            return this.getSuffixes(e).map((function(e) {
                                return t + e
                            }))
                        }
                    }, {
                        key: "getSuffixes",
                        value: function(e) {
                            var t = this,
                                n = this.getRule(e);
                            return n ? n.numbers.map((function(n) {
                                return t.getSuffix(e, n)
                            })) : []
                        }
                    }, {
                        key: "getSuffix",
                        value: function(e, t) {
                            var n = this,
                                i = this.getRule(e);
                            if (i) {
                                var o = i.noAbs ? i.plurals(t) : i.plurals(Math.abs(t)),
                                    r = i.numbers[o];
                                this.options.simplifyPluralSuffix && 2 === i.numbers.length && 1 === i.numbers[0] && (2 === r ? r = "plural" : 1 === r && (r = ""));
                                var a = function() {
                                    return n.options.prepend && r.toString() ? n.options.prepend + r.toString() : r.toString()
                                };
                                return "v1" === this.options.compatibilityJSON ? 1 === r ? "" : "number" === typeof r ? "_plural_".concat(r.toString()) : a() : "v2" === this.options.compatibilityJSON || this.options.simplifyPluralSuffix && 2 === i.numbers.length && 1 === i.numbers[0] ? a() : this.options.prepend && o.toString() ? this.options.prepend + o.toString() : o.toString()
                            }
                            return this.logger.warn("no plural rule found for: ".concat(e)), ""
                        }
                    }]), e
                }(),
                H = function() {
                    function e() {
                        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                        s(this, e), this.logger = v.create("interpolator"), this.options = t, this.format = t.interpolation && t.interpolation.format || function(e) {
                            return e
                        }, this.init(t)
                    }
                    return (0, u.Z)(e, [{
                        key: "init",
                        value: function() {
                            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                            e.interpolation || (e.interpolation = {
                                escapeValue: !0
                            });
                            var t = e.interpolation;
                            this.escape = void 0 !== t.escape ? t.escape : N, this.escapeValue = void 0 === t.escapeValue || t.escapeValue, this.useRawValueToEscape = void 0 !== t.useRawValueToEscape && t.useRawValueToEscape, this.prefix = t.prefix ? C(t.prefix) : t.prefixEscaped || "{{", this.suffix = t.suffix ? C(t.suffix) : t.suffixEscaped || "}}", this.formatSeparator = t.formatSeparator ? t.formatSeparator : t.formatSeparator || ",", this.unescapePrefix = t.unescapeSuffix ? "" : t.unescapePrefix || "-", this.unescapeSuffix = this.unescapePrefix ? "" : t.unescapeSuffix || "", this.nestingPrefix = t.nestingPrefix ? C(t.nestingPrefix) : t.nestingPrefixEscaped || C("$t("), this.nestingSuffix = t.nestingSuffix ? C(t.nestingSuffix) : t.nestingSuffixEscaped || C(")"), this.nestingOptionsSeparator = t.nestingOptionsSeparator ? t.nestingOptionsSeparator : t.nestingOptionsSeparator || ",", this.maxReplaces = t.maxReplaces ? t.maxReplaces : 1e3, this.alwaysFormat = void 0 !== t.alwaysFormat && t.alwaysFormat, this.resetRegExp()
                        }
                    }, {
                        key: "reset",
                        value: function() {
                            this.options && this.init(this.options)
                        }
                    }, {
                        key: "resetRegExp",
                        value: function() {
                            var e = "".concat(this.prefix, "(.+?)").concat(this.suffix);
                            this.regexp = new RegExp(e, "g");
                            var t = "".concat(this.prefix).concat(this.unescapePrefix, "(.+?)").concat(this.unescapeSuffix).concat(this.suffix);
                            this.regexpUnescape = new RegExp(t, "g");
                            var n = "".concat(this.nestingPrefix, "(.+?)").concat(this.nestingSuffix);
                            this.nestingRegexp = new RegExp(n, "g")
                        }
                    }, {
                        key: "interpolate",
                        value: function(e, t, n, i) {
                            var o, r, a, s = this,
                                u = this.options && this.options.interpolation && this.options.interpolation.defaultVariables || {};

                            function l(e) {
                                return e.replace(/\$/g, "$$$$")
                            }
                            var c = function(e) {
                                if (e.indexOf(s.formatSeparator) < 0) {
                                    var o = L(t, u, e);
                                    return s.alwaysFormat ? s.format(o, void 0, n) : o
                                }
                                var r = e.split(s.formatSeparator),
                                    a = r.shift().trim(),
                                    l = r.join(s.formatSeparator).trim();
                                return s.format(L(t, u, a), l, n, i)
                            };
                            this.resetRegExp();
                            var p = i && i.missingInterpolationHandler || this.options.missingInterpolationHandler,
                                g = i && i.interpolation && i.interpolation.skipOnVariables || this.options.interpolation.skipOnVariables;
                            return [{
                                regex: this.regexpUnescape,
                                safeValue: function(e) {
                                    return l(e)
                                }
                            }, {
                                regex: this.regexp,
                                safeValue: function(e) {
                                    return s.escapeValue ? l(s.escape(e)) : l(e)
                                }
                            }].forEach((function(t) {
                                for (a = 0; o = t.regex.exec(e);) {
                                    if (void 0 === (r = c(o[1].trim())))
                                        if ("function" === typeof p) {
                                            var n = p(e, o, i);
                                            r = "string" === typeof n ? n : ""
                                        } else {
                                            if (g) {
                                                r = o[0];
                                                continue
                                            }
                                            s.logger.warn("missed to pass in variable ".concat(o[1], " for interpolating ").concat(e)), r = ""
                                        }
                                    else "string" === typeof r || s.useRawValueToEscape || (r = b(r));
                                    if (e = e.replace(o[0], t.safeValue(r)), t.regex.lastIndex = 0, ++a >= s.maxReplaces) break
                                }
                            })), e
                        }
                    }, {
                        key: "nest",
                        value: function(e, t) {
                            var n, i, o = this,
                                r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {},
                                s = a({}, r);

                            function u(e, t) {
                                var n = this.nestingOptionsSeparator;
                                if (e.indexOf(n) < 0) return e;
                                var i = e.split(new RegExp("".concat(n, "[ ]*{"))),
                                    o = "{".concat(i[1]);
                                e = i[0], o = (o = this.interpolate(o, s)).replace(/'/g, '"');
                                try {
                                    s = JSON.parse(o), t && (s = a({}, t, s))
                                } catch (r) {
                                    return this.logger.warn("failed parsing options string in nesting for key ".concat(e), r), "".concat(e).concat(n).concat(o)
                                }
                                return delete s.defaultValue, e
                            }
                            for (s.applyPostProcessor = !1, delete s.defaultValue; n = this.nestingRegexp.exec(e);) {
                                var l = [],
                                    c = !1;
                                if (n[0].includes(this.formatSeparator) && !/{.*}/.test(n[1])) {
                                    var p = n[1].split(this.formatSeparator).map((function(e) {
                                        return e.trim()
                                    }));
                                    n[1] = p.shift(), l = p, c = !0
                                }
                                if ((i = t(u.call(this, n[1].trim(), s), s)) && n[0] === e && "string" !== typeof i) return i;
                                "string" !== typeof i && (i = b(i)), i || (this.logger.warn("missed to resolve ".concat(n[1], " for nesting ").concat(e)), i = ""), c && (i = l.reduce((function(e, t) {
                                    return o.format(e, t, r.lng, r)
                                }), i.trim())), e = e.replace(n[0], i), this.regexp.lastIndex = 0
                            }
                            return e
                        }
                    }]), e
                }();
            var K = function(e) {
                function t(e, n, i) {
                    var o, r = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : {};
                    return s(this, t), o = c(this, (0, p.Z)(t).call(this)), j && y.call((0, l.Z)(o)), o.backend = e, o.store = n, o.services = i, o.languageUtils = i.languageUtils, o.options = r, o.logger = v.create("backendConnector"), o.state = {}, o.queue = [], o.backend && o.backend.init && o.backend.init(i, r.backend, r), o
                }
                return f(t, e), (0, u.Z)(t, [{
                    key: "queueLoad",
                    value: function(e, t, n, i) {
                        var o = this,
                            r = [],
                            a = [],
                            s = [],
                            u = [];
                        return e.forEach((function(e) {
                            var i = !0;
                            t.forEach((function(t) {
                                var s = "".concat(e, "|").concat(t);
                                !n.reload && o.store.hasResourceBundle(e, t) ? o.state[s] = 2 : o.state[s] < 0 || (1 === o.state[s] ? a.indexOf(s) < 0 && a.push(s) : (o.state[s] = 1, i = !1, a.indexOf(s) < 0 && a.push(s), r.indexOf(s) < 0 && r.push(s), u.indexOf(t) < 0 && u.push(t)))
                            })), i || s.push(e)
                        })), (r.length || a.length) && this.queue.push({
                            pending: a,
                            loaded: {},
                            errors: [],
                            callback: i
                        }), {
                            toLoad: r,
                            pending: a,
                            toLoadLanguages: s,
                            toLoadNamespaces: u
                        }
                    }
                }, {
                    key: "loaded",
                    value: function(e, t, n) {
                        var i = e.split("|"),
                            o = i[0],
                            r = i[1];
                        t && this.emit("failedLoading", o, r, t), n && this.store.addResourceBundle(o, r, n), this.state[e] = t ? -1 : 2;
                        var a = {};
                        this.queue.forEach((function(n) {
                            ! function(e, t, n, i) {
                                var o = x(e, t, Object),
                                    r = o.obj,
                                    a = o.k;
                                r[a] = r[a] || [], i && (r[a] = r[a].concat(n)), i || r[a].push(n)
                            }(n.loaded, [o], r),
                            function(e, t) {
                                for (var n = e.indexOf(t); - 1 !== n;) e.splice(n, 1), n = e.indexOf(t)
                            }(n.pending, e), t && n.errors.push(t), 0 !== n.pending.length || n.done || (Object.keys(n.loaded).forEach((function(e) {
                                a[e] || (a[e] = []), n.loaded[e].length && n.loaded[e].forEach((function(t) {
                                    a[e].indexOf(t) < 0 && a[e].push(t)
                                }))
                            })), n.done = !0, n.errors.length ? n.callback(n.errors) : n.callback())
                        })), this.emit("loaded", a), this.queue = this.queue.filter((function(e) {
                            return !e.done
                        }))
                    }
                }, {
                    key: "read",
                    value: function(e, t, n) {
                        var i = this,
                            o = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 0,
                            r = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : 350,
                            a = arguments.length > 5 ? arguments[5] : void 0;
                        return e.length ? this.backend[n](e, t, (function(s, u) {
                            s && u && o < 5 ? setTimeout((function() {
                                i.read.call(i, e, t, n, o + 1, 2 * r, a)
                            }), r) : a(s, u)
                        })) : a(null, {})
                    }
                }, {
                    key: "prepareLoading",
                    value: function(e, t) {
                        var n = this,
                            i = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {},
                            o = arguments.length > 3 ? arguments[3] : void 0;
                        if (!this.backend) return this.logger.warn("No backend was added via i18next.use. Will not load resources."), o && o();
                        "string" === typeof e && (e = this.languageUtils.toResolveHierarchy(e)), "string" === typeof t && (t = [t]);
                        var r = this.queueLoad(e, t, i, o);
                        if (!r.toLoad.length) return r.pending.length || o(), null;
                        r.toLoad.forEach((function(e) {
                            n.loadOne(e)
                        }))
                    }
                }, {
                    key: "load",
                    value: function(e, t, n) {
                        this.prepareLoading(e, t, {}, n)
                    }
                }, {
                    key: "reload",
                    value: function(e, t, n) {
                        this.prepareLoading(e, t, {
                            reload: !0
                        }, n)
                    }
                }, {
                    key: "loadOne",
                    value: function(e) {
                        var t = this,
                            n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "",
                            i = e.split("|"),
                            o = i[0],
                            r = i[1];
                        this.read(o, r, "read", void 0, void 0, (function(i, a) {
                            i && t.logger.warn("".concat(n, "loading namespace ").concat(r, " for language ").concat(o, " failed"), i), !i && a && t.logger.log("".concat(n, "loaded namespace ").concat(r, " for language ").concat(o), a), t.loaded(e, i, a)
                        }))
                    }
                }, {
                    key: "saveMissing",
                    value: function(e, t, n, i, o) {
                        var r = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : {};
                        this.services.utils && this.services.utils.hasLoadedNamespace && !this.services.utils.hasLoadedNamespace(t) ? this.logger.warn('did not save key "'.concat(n, '" as the namespace "').concat(t, '" was not yet loaded'), "This means something IS WRONG in your setup. You access the t function before i18next.init / i18next.loadNamespace / i18next.changeLanguage was done. Wait for the callback or Promise to resolve before accessing it!!!") : void 0 !== n && null !== n && "" !== n && (this.backend && this.backend.create && this.backend.create(e, t, n, i, null, a({}, r, {
                            isUpdate: o
                        })), e && e[0] && this.store.addResource(e[0], t, n, i))
                    }
                }]), t
            }(y);

            function M() {
                return {
                    debug: !1,
                    initImmediate: !0,
                    ns: ["translation"],
                    defaultNS: ["translation"],
                    fallbackLng: ["dev"],
                    fallbackNS: !1,
                    whitelist: !1,
                    nonExplicitWhitelist: !1,
                    supportedLngs: !1,
                    nonExplicitSupportedLngs: !1,
                    load: "all",
                    preload: !1,
                    simplifyPluralSuffix: !0,
                    keySeparator: ".",
                    nsSeparator: ":",
                    pluralSeparator: "_",
                    contextSeparator: "_",
                    partialBundledLanguages: !1,
                    saveMissing: !1,
                    updateMissing: !1,
                    saveMissingTo: "fallback",
                    saveMissingPlurals: !0,
                    missingKeyHandler: !1,
                    missingInterpolationHandler: !1,
                    postProcess: !1,
                    postProcessPassResolved: !1,
                    returnNull: !0,
                    returnEmptyString: !0,
                    returnObjects: !1,
                    joinArrays: !1,
                    returnedObjectHandler: !1,
                    parseMissingKeyHandler: !1,
                    appendNamespaceToMissingKey: !1,
                    appendNamespaceToCIMode: !1,
                    overloadTranslationOptionHandler: function(e) {
                        var t = {};
                        if ("object" === (0, i.Z)(e[1]) && (t = e[1]), "string" === typeof e[1] && (t.defaultValue = e[1]), "string" === typeof e[2] && (t.tDescription = e[2]), "object" === (0, i.Z)(e[2]) || "object" === (0, i.Z)(e[3])) {
                            var n = e[3] || e[2];
                            Object.keys(n).forEach((function(e) {
                                t[e] = n[e]
                            }))
                        }
                        return t
                    },
                    interpolation: {
                        escapeValue: !0,
                        format: function(e, t, n, i) {
                            return e
                        },
                        prefix: "{{",
                        suffix: "}}",
                        formatSeparator: ",",
                        unescapePrefix: "-",
                        nestingPrefix: "$t(",
                        nestingSuffix: ")",
                        nestingOptionsSeparator: ",",
                        maxReplaces: 1e3,
                        skipOnVariables: !1
                    }
                }
            }

            function B(e) {
                return "string" === typeof e.ns && (e.ns = [e.ns]), "string" === typeof e.fallbackLng && (e.fallbackLng = [e.fallbackLng]), "string" === typeof e.fallbackNS && (e.fallbackNS = [e.fallbackNS]), e.whitelist && (e.whitelist && e.whitelist.indexOf("cimode") < 0 && (e.whitelist = e.whitelist.concat(["cimode"])), e.supportedLngs = e.whitelist), e.nonExplicitWhitelist && (e.nonExplicitSupportedLngs = e.nonExplicitWhitelist), e.supportedLngs && e.supportedLngs.indexOf("cimode") < 0 && (e.supportedLngs = e.supportedLngs.concat(["cimode"])), e
            }

            function _() {}
            var z = function(e) {
                    function t() {
                        var e, n = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                            i = arguments.length > 1 ? arguments[1] : void 0;
                        if (s(this, t), e = c(this, (0, p.Z)(t).call(this)), j && y.call((0, l.Z)(e)), e.options = B(n), e.services = {}, e.logger = v, e.modules = {
                                external: []
                            }, i && !e.isInitialized && !n.isClone) {
                            if (!e.options.initImmediate) return e.init(n, i), c(e, (0, l.Z)(e));
                            setTimeout((function() {
                                e.init(n, i)
                            }), 0)
                        }
                        return e
                    }
                    return f(t, e), (0, u.Z)(t, [{
                        key: "init",
                        value: function() {
                            var e = this,
                                t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                                n = arguments.length > 1 ? arguments[1] : void 0;

                            function i(e) {
                                return e ? "function" === typeof e ? new e : e : null
                            }
                            if ("function" === typeof t && (n = t, t = {}), t.whitelist && !t.supportedLngs && this.logger.deprecate("whitelist", 'option "whitelist" will be renamed to "supportedLngs" in the next major - please make sure to rename this option asap.'), t.nonExplicitWhitelist && !t.nonExplicitSupportedLngs && this.logger.deprecate("whitelist", 'options "nonExplicitWhitelist" will be renamed to "nonExplicitSupportedLngs" in the next major - please make sure to rename this option asap.'), this.options = a({}, M(), this.options, B(t)), this.format = this.options.interpolation.format, n || (n = _), !this.options.isClone) {
                                this.modules.logger ? v.init(i(this.modules.logger), this.options) : v.init(null, this.options);
                                var o = new Z(this.options);
                                this.store = new E(this.options.resources, this.options);
                                var r = this.services;
                                r.logger = v, r.resourceStore = this.store, r.languageUtils = o, r.pluralResolver = new I(o, {
                                    prepend: this.options.pluralSeparator,
                                    compatibilityJSON: this.options.compatibilityJSON,
                                    simplifyPluralSuffix: this.options.simplifyPluralSuffix
                                }), r.interpolator = new H(this.options), r.utils = {
                                    hasLoadedNamespace: this.hasLoadedNamespace.bind(this)
                                }, r.backendConnector = new K(i(this.modules.backend), r.resourceStore, r, this.options), r.backendConnector.on("*", (function(t) {
                                    for (var n = arguments.length, i = new Array(n > 1 ? n - 1 : 0), o = 1; o < n; o++) i[o - 1] = arguments[o];
                                    e.emit.apply(e, [t].concat(i))
                                })), this.modules.languageDetector && (r.languageDetector = i(this.modules.languageDetector), r.languageDetector.init(r, this.options.detection, this.options)), this.modules.i18nFormat && (r.i18nFormat = i(this.modules.i18nFormat), r.i18nFormat.init && r.i18nFormat.init(this)), this.translator = new A(this.services, this.options), this.translator.on("*", (function(t) {
                                    for (var n = arguments.length, i = new Array(n > 1 ? n - 1 : 0), o = 1; o < n; o++) i[o - 1] = arguments[o];
                                    e.emit.apply(e, [t].concat(i))
                                })), this.modules.external.forEach((function(t) {
                                    t.init && t.init(e)
                                }))
                            }
                            if (this.options.fallbackLng && !this.services.languageDetector && !this.options.lng) {
                                var s = this.services.languageUtils.getFallbackCodes(this.options.fallbackLng);
                                s.length > 0 && "dev" !== s[0] && (this.options.lng = s[0])
                            }
                            this.services.languageDetector || this.options.lng || this.logger.warn("init: no languageDetector is used and no lng is defined");
                            var u = ["getResource", "hasResourceBundle", "getResourceBundle", "getDataByLanguage"];
                            u.forEach((function(t) {
                                e[t] = function() {
                                    var n;
                                    return (n = e.store)[t].apply(n, arguments)
                                }
                            }));
                            var l = ["addResource", "addResources", "addResourceBundle", "removeResourceBundle"];
                            l.forEach((function(t) {
                                e[t] = function() {
                                    var n;
                                    return (n = e.store)[t].apply(n, arguments), e
                                }
                            }));
                            var c = m(),
                                p = function() {
                                    var t = function(t, i) {
                                        e.isInitialized && e.logger.warn("init: i18next is already initialized. You should call init just once!"), e.isInitialized = !0, e.options.isClone || e.logger.log("initialized", e.options), e.emit("initialized", e.options), c.resolve(i), n(t, i)
                                    };
                                    if (e.languages && "v1" !== e.options.compatibilityAPI && !e.isInitialized) return t(null, e.t.bind(e));
                                    e.changeLanguage(e.options.lng, t)
                                };
                            return this.options.resources || !this.options.initImmediate ? p() : setTimeout(p, 0), c
                        }
                    }, {
                        key: "loadResources",
                        value: function(e) {
                            var t = this,
                                n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : _,
                                i = n,
                                o = "string" === typeof e ? e : this.language;
                            if ("function" === typeof e && (i = e), !this.options.resources || this.options.partialBundledLanguages) {
                                if (o && "cimode" === o.toLowerCase()) return i();
                                var r = [],
                                    a = function(e) {
                                        e && t.services.languageUtils.toResolveHierarchy(e).forEach((function(e) {
                                            r.indexOf(e) < 0 && r.push(e)
                                        }))
                                    };
                                if (o) a(o);
                                else {
                                    var s = this.services.languageUtils.getFallbackCodes(this.options.fallbackLng);
                                    s.forEach((function(e) {
                                        return a(e)
                                    }))
                                }
                                this.options.preload && this.options.preload.forEach((function(e) {
                                    return a(e)
                                })), this.services.backendConnector.load(r, this.options.ns, i)
                            } else i(null)
                        }
                    }, {
                        key: "reloadResources",
                        value: function(e, t, n) {
                            var i = m();
                            return e || (e = this.languages), t || (t = this.options.ns), n || (n = _), this.services.backendConnector.reload(e, t, (function(e) {
                                i.resolve(), n(e)
                            })), i
                        }
                    }, {
                        key: "use",
                        value: function(e) {
                            if (!e) throw new Error("You are passing an undefined module! Please check the object you are passing to i18next.use()");
                            if (!e.type) throw new Error("You are passing a wrong module! Please check the object you are passing to i18next.use()");
                            return "backend" === e.type && (this.modules.backend = e), ("logger" === e.type || e.log && e.warn && e.error) && (this.modules.logger = e), "languageDetector" === e.type && (this.modules.languageDetector = e), "i18nFormat" === e.type && (this.modules.i18nFormat = e), "postProcessor" === e.type && P.addPostProcessor(e), "3rdParty" === e.type && this.modules.external.push(e), this
                        }
                    }, {
                        key: "changeLanguage",
                        value: function(e, t) {
                            var n = this;
                            this.isLanguageChangingTo = e;
                            var i = m();
                            this.emit("languageChanging", e);
                            var o = function(e) {
                                var o = "string" === typeof e ? e : n.services.languageUtils.getBestMatchFromCodes(e);
                                o && (n.language || (n.language = o, n.languages = n.services.languageUtils.toResolveHierarchy(o)), n.translator.language || n.translator.changeLanguage(o), n.services.languageDetector && n.services.languageDetector.cacheUserLanguage(o)), n.loadResources(o, (function(e) {
                                    ! function(e, o) {
                                        o ? (n.language = o, n.languages = n.services.languageUtils.toResolveHierarchy(o), n.translator.changeLanguage(o), n.isLanguageChangingTo = void 0, n.emit("languageChanged", o), n.logger.log("languageChanged", o)) : n.isLanguageChangingTo = void 0, i.resolve((function() {
                                            return n.t.apply(n, arguments)
                                        })), t && t(e, (function() {
                                            return n.t.apply(n, arguments)
                                        }))
                                    }(e, o)
                                }))
                            };
                            return e || !this.services.languageDetector || this.services.languageDetector.async ? !e && this.services.languageDetector && this.services.languageDetector.async ? this.services.languageDetector.detect(o) : o(e) : o(this.services.languageDetector.detect()), i
                        }
                    }, {
                        key: "getFixedT",
                        value: function(e, t) {
                            var n = this,
                                o = function e(t, o) {
                                    var r;
                                    if ("object" !== (0, i.Z)(o)) {
                                        for (var s = arguments.length, u = new Array(s > 2 ? s - 2 : 0), l = 2; l < s; l++) u[l - 2] = arguments[l];
                                        r = n.options.overloadTranslationOptionHandler([t, o].concat(u))
                                    } else r = a({}, o);
                                    return r.lng = r.lng || e.lng, r.lngs = r.lngs || e.lngs, r.ns = r.ns || e.ns, n.t(t, r)
                                };
                            return "string" === typeof e ? o.lng = e : o.lngs = e, o.ns = t, o
                        }
                    }, {
                        key: "t",
                        value: function() {
                            var e;
                            return this.translator && (e = this.translator).translate.apply(e, arguments)
                        }
                    }, {
                        key: "exists",
                        value: function() {
                            var e;
                            return this.translator && (e = this.translator).exists.apply(e, arguments)
                        }
                    }, {
                        key: "setDefaultNamespace",
                        value: function(e) {
                            this.options.defaultNS = e
                        }
                    }, {
                        key: "hasLoadedNamespace",
                        value: function(e) {
                            var t = this,
                                n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                            if (!this.isInitialized) return this.logger.warn("hasLoadedNamespace: i18next was not initialized", this.languages), !1;
                            if (!this.languages || !this.languages.length) return this.logger.warn("hasLoadedNamespace: i18n.languages were undefined or empty", this.languages), !1;
                            var i = this.languages[0],
                                o = !!this.options && this.options.fallbackLng,
                                r = this.languages[this.languages.length - 1];
                            if ("cimode" === i.toLowerCase()) return !0;
                            var a = function(e, n) {
                                var i = t.services.backendConnector.state["".concat(e, "|").concat(n)];
                                return -1 === i || 2 === i
                            };
                            if (n.precheck) {
                                var s = n.precheck(this, a);
                                if (void 0 !== s) return s
                            }
                            return !!this.hasResourceBundle(i, e) || (!this.services.backendConnector.backend || !(!a(i, e) || o && !a(r, e)))
                        }
                    }, {
                        key: "loadNamespaces",
                        value: function(e, t) {
                            var n = this,
                                i = m();
                            return this.options.ns ? ("string" === typeof e && (e = [e]), e.forEach((function(e) {
                                n.options.ns.indexOf(e) < 0 && n.options.ns.push(e)
                            })), this.loadResources((function(e) {
                                i.resolve(), t && t(e)
                            })), i) : (t && t(), Promise.resolve())
                        }
                    }, {
                        key: "loadLanguages",
                        value: function(e, t) {
                            var n = m();
                            "string" === typeof e && (e = [e]);
                            var i = this.options.preload || [],
                                o = e.filter((function(e) {
                                    return i.indexOf(e) < 0
                                }));
                            return o.length ? (this.options.preload = i.concat(o), this.loadResources((function(e) {
                                n.resolve(), t && t(e)
                            })), n) : (t && t(), Promise.resolve())
                        }
                    }, {
                        key: "dir",
                        value: function(e) {
                            if (e || (e = this.languages && this.languages.length > 0 ? this.languages[0] : this.language), !e) return "rtl";
                            return ["ar", "shu", "sqr", "ssh", "xaa", "yhd", "yud", "aao", "abh", "abv", "acm", "acq", "acw", "acx", "acy", "adf", "ads", "aeb", "aec", "afb", "ajp", "apc", "apd", "arb", "arq", "ars", "ary", "arz", "auz", "avl", "ayh", "ayl", "ayn", "ayp", "bbz", "pga", "he", "iw", "ps", "pbt", "pbu", "pst", "prp", "prd", "ug", "ur", "ydd", "yds", "yih", "ji", "yi", "hbo", "men", "xmn", "fa", "jpr", "peo", "pes", "prs", "dv", "sam"].indexOf(this.services.languageUtils.getLanguagePartFromCode(e)) >= 0 ? "rtl" : "ltr"
                        }
                    }, {
                        key: "createInstance",
                        value: function() {
                            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                                n = arguments.length > 1 ? arguments[1] : void 0;
                            return new t(e, n)
                        }
                    }, {
                        key: "cloneInstance",
                        value: function() {
                            var e = this,
                                n = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                                i = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : _,
                                o = a({}, this.options, n, {
                                    isClone: !0
                                }),
                                r = new t(o),
                                s = ["store", "services", "language"];
                            return s.forEach((function(t) {
                                r[t] = e[t]
                            })), r.services = a({}, this.services), r.services.utils = {
                                hasLoadedNamespace: r.hasLoadedNamespace.bind(r)
                            }, r.translator = new A(r.services, r.options), r.translator.on("*", (function(e) {
                                for (var t = arguments.length, n = new Array(t > 1 ? t - 1 : 0), i = 1; i < t; i++) n[i - 1] = arguments[i];
                                r.emit.apply(r, [e].concat(n))
                            })), r.init(o, i), r.translator.options = r.options, r.translator.backendConnector.services.utils = {
                                hasLoadedNamespace: r.hasLoadedNamespace.bind(r)
                            }, r
                        }
                    }]), t
                }(y),
                W = new z
        },
        43144: function(e, t, n) {
            n.d(t, {
                Z: function() {
                    return r
                }
            });
            var i = n(83997);

            function o(e, t) {
                for (var n = 0; n < t.length; n++) {
                    var o = t[n];
                    o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), Object.defineProperty(e, (0, i.Z)(o.key), o)
                }
            }

            function r(e, t, n) {
                return t && o(e.prototype, t), n && o(e, n), Object.defineProperty(e, "prototype", {
                    writable: !1
                }), e
            }
        },
        83997: function(e, t, n) {
            n.d(t, {
                Z: function() {
                    return o
                }
            });
            var i = n(71002);

            function o(e) {
                var t = function(e, t) {
                    if ("object" != (0, i.Z)(e) || !e) return e;
                    var n = e[Symbol.toPrimitive];
                    if (void 0 !== n) {
                        var o = n.call(e, t || "default");
                        if ("object" != (0, i.Z)(o)) return o;
                        throw new TypeError("@@toPrimitive must return a primitive value.")
                    }
                    return ("string" === t ? String : Number)(e)
                }(e, "string");
                return "symbol" == (0, i.Z)(t) ? t : String(t)
            }
        },
        71002: function(e, t, n) {
            function i(e) {
                return i = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
                    return typeof e
                } : function(e) {
                    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
                }, i(e)
            }
            n.d(t, {
                Z: function() {
                    return i
                }
            })
        }
    }
]);