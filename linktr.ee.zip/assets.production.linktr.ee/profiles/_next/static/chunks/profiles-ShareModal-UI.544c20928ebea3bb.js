(self.__LOADABLE_LOADED_CHUNKS__ = self.__LOADABLE_LOADED_CHUNKS__ || []).push([
    [619], {
        55509: function(e, t, r) {
            "use strict";
            var n = this && this.__importDefault || function(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            };
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            const o = n(r(67294)),
                l = n(r(28043));
            t.default = o.default.forwardRef((({
                state: e,
                className: t,
                title: r = "Flag",
                description: n,
                ariaHidden: c
            }, a) => o.default.createElement(l.default, {
                state: e,
                size: "md",
                className: t,
                title: r,
                description: n,
                ariaHidden: c,
                ref: a
            }, o.default.createElement("path", {
                fillRule: "evenodd",
                d: "M2 0v16h1V9h11.5l.38-.82L12.16 5l2.72-3.17L14.5 1H3V0H2Zm1 2v6h10.41l-2.29-2.67v-.65L13.42 2H3Z",
                fill: "currentColor"
            }))))
        },
        25185: function(e, t, r) {
            "use strict";
            var n = this && this.__importDefault || function(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            };
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            const o = n(r(67294)),
                l = n(r(28043));
            t.default = o.default.forwardRef((({
                state: e,
                className: t,
                title: r = "Lock",
                description: n,
                ariaHidden: c
            }, a) => o.default.createElement(l.default, {
                state: e,
                size: "md",
                className: t,
                title: r,
                description: n,
                ariaHidden: c,
                ref: a
            }, o.default.createElement("path", {
                fillRule: "evenodd",
                d: "M4 4a4 4 0 1 1 8 0v1h2.5l.5.5v10l-.5.5h-13l-.5-.5v-10l.5-.5H4V4Zm7 0v1H5V4a3 3 0 1 1 6 0ZM2 6v9h12V6H2Zm7 4.5a1 1 0 1 1-2 0 1 1 0 0 1 2 0Z",
                fill: "currentColor"
            }))))
        },
        58350: function(e, t, r) {
            "use strict";
            t.N = void 0;
            const n = r(74999);
            class o extends n.AbstractEvent {
                constructor(e) {
                    super(e, "ProfileSignupCtaViewed")
                }
            }
            t.N = o
        },
        23493: function(e, t, r) {
            var n = r(23279),
                o = r(13218);
            e.exports = function(e, t, r) {
                var l = !0,
                    c = !0;
                if ("function" != typeof e) throw new TypeError("Expected a function");
                return o(r) && (l = "leading" in r ? !!r.leading : l, c = "trailing" in r ? !!r.trailing : c), n(e, t, {
                    leading: l,
                    maxWait: t,
                    trailing: c
                })
            }
        },
        88716: function(e, t, r) {
            "use strict";
            r.r(t), r.d(t, {
                default: function() {
                    return ut
                }
            });
            var n = r(67294),
                o = r(57502),
                l = r(84669),
                c = r(58350),
                a = r(62082),
                i = r(50556);
            var s = e => "local" === e ? "http://profiles.test:3000" : "https://".concat("qa" === e ? "qa." : "", "linktr.ee"),
                u = r(85893);
            var d = e => {
                    let {
                        handleClose: t
                    } = e;
                    return (0, u.jsxs)("button", {
                        onClick: t,
                        className: "flex justify-center items-center rounded-sm p-2 hover:bg-[#f3f3f1] active:bg-[#f3f3f1] focus:outline-none focus-visible:ring-2 focus-visible:ring-black",
                        children: [(0, u.jsx)("span", {
                            className: "sr-only",
                            children: "Close"
                        }), (0, u.jsx)("svg", {
                            width: "16",
                            height: "16",
                            viewBox: "0 0 16 16",
                            children: (0, u.jsx)("path", {
                                d: "M13.354 3.354 13.707 3 13 2.293l-.354.353zM2.647 12.647 2.293 13l.707.707.354-.353zm.707-10L3 2.292 2.293 3l.354.354zm9.293 10.707.353.353.707-.707-.353-.354zm0-10.708-10 10 .707.708 10-10zm-10 .708 10 10 .707-.707-10-10z"
                            })
                        })]
                    })
                },
                p = r(10374),
                f = r.n(p);
            var h = async (e, t) => {
                    const r = await f().post("/api/profiles/short-link/get-or-create", {
                            accountUuid: e,
                            linkId: t
                        }),
                        {
                            data: n
                        } = r;
                    return n
                },
                b = r(59499),
                v = r(4730);
            var O = e => {
                let {
                    shape: t,
                    fill: r,
                    rx: n
                } = e;
                return "circle" === t ? (0, u.jsx)("circle", {
                    cx: "50%",
                    cy: "50%",
                    r: "50%",
                    fill: r
                }) : (0, u.jsx)("rect", {
                    width: "100%",
                    height: "100%",
                    rx: n,
                    fill: r
                })
            };

            function j(e, t) {
                var r = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(e);
                    t && (n = n.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), r.push.apply(r, n)
                }
                return r
            }

            function m(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var r = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? j(Object(r), !0).forEach((function(t) {
                        (0, b.Z)(e, t, r[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : j(Object(r)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(r, t))
                    }))
                }
                return e
            }
            var g = e => (0, u.jsxs)("svg", m(m({
                viewBox: "0 0 24 24"
            }, e), {}, {
                children: [(0, u.jsx)(O, {
                    shape: e.shape,
                    fill: "#1877F2",
                    rx: 4
                }), (0, u.jsx)("path", {
                    d: "M18 12a6 6 0 1 0-12 0 6 6 0 0 0 5.063 5.928v-4.193H9.539V12h1.524v-1.322c0-1.503.895-2.334 2.266-2.334.656 0 1.343.117 1.343.117v1.477h-.757c-.745 0-.977.463-.977.937V12h1.664l-.267 1.735h-1.398v4.193A6 6 0 0 0 18 12",
                    fill: "#fff"
                })]
            }));

            function x(e, t) {
                var r = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(e);
                    t && (n = n.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), r.push.apply(r, n)
                }
                return r
            }

            function y(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var r = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? x(Object(r), !0).forEach((function(t) {
                        (0, b.Z)(e, t, r[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : x(Object(r)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(r, t))
                    }))
                }
                return e
            }
            var w = e => (0, u.jsxs)("svg", y(y({
                viewBox: "0 0 24 24"
            }, e), {}, {
                children: [(0, u.jsx)(O, {
                    shape: e.shape,
                    fill: "#0A66C2",
                    rx: 4
                }), (0, u.jsx)("path", {
                    d: "M8.656 10.132h-2.46V18h2.46zm.221-2.705A1.417 1.417 0 0 0 7.47 6h-.044a1.426 1.426 0 0 0 0 2.852A1.416 1.416 0 0 0 8.877 7.47zM18 13.22c0-2.365-1.505-3.285-3-3.285a2.8 2.8 0 0 0-2.488 1.269h-.07v-1.072h-2.31V18h2.458v-4.186a1.633 1.633 0 0 1 1.476-1.76h.093c.782 0 1.362.492 1.362 1.731V18h2.46z",
                    fill: "#fff"
                })]
            }));

            function P(e, t) {
                var r = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(e);
                    t && (n = n.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), r.push.apply(r, n)
                }
                return r
            }

            function k(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var r = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? P(Object(r), !0).forEach((function(t) {
                        (0, b.Z)(e, t, r[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : P(Object(r)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(r, t))
                    }))
                }
                return e
            }
            var E = e => (0, u.jsxs)("svg", k(k({
                viewBox: "0 0 24 24"
            }, e), {}, {
                children: [(0, u.jsx)("rect", {
                    width: "24",
                    height: "24",
                    rx: "4",
                    fill: "#1DA1F2"
                }), (0, u.jsx)("path", {
                    d: "M18 8.352a5 5 0 0 1-1.414.386A2.46 2.46 0 0 0 17.67 7.38a4.9 4.9 0 0 1-1.564.595 2.47 2.47 0 0 0-1.796-.774 2.458 2.458 0 0 0-2.399 3.012A7 7 0 0 1 6.836 7.65a2.45 2.45 0 0 0 .762 3.275 2.46 2.46 0 0 1-1.115-.307v.031c0 1.189.848 2.18 1.975 2.406a2.5 2.5 0 0 1-1.112.042 2.46 2.46 0 0 0 2.3 1.703A4.95 4.95 0 0 1 6 15.816a7 7 0 0 0 3.773 1.103c4.53 0 7.006-3.738 7.006-6.98q0-.159-.008-.317A5 5 0 0 0 18 8.353z",
                    fill: "#fff"
                })]
            }));

            function S(e, t) {
                var r = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(e);
                    t && (n = n.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), r.push.apply(r, n)
                }
                return r
            }

            function C(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var r = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? S(Object(r), !0).forEach((function(t) {
                        (0, b.Z)(e, t, r[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : S(Object(r)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(r, t))
                    }))
                }
                return e
            }
            var L = e => (0, u.jsxs)("svg", C(C({
                viewBox: "0 0 48 48"
            }, e), {}, {
                children: [(0, u.jsx)(O, {
                    shape: e.shape,
                    fill: "black",
                    rx: 4
                }), (0, u.jsx)("path", {
                    d: "M11.559 12.251L20.825 25.1736L11.5 35.6775H13.6L21.763 26.4794L28.359 35.6786H35.5L25.712 22.029L34.392 12.25H32.293L24.775 20.7211L18.7 12.251H11.559ZM14.645 13.8625H17.925L32.413 34.0661H29.133L14.644 13.8635L14.645 13.8625Z",
                    fill: "white"
                })]
            }));

            function N(e, t) {
                var r = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(e);
                    t && (n = n.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), r.push.apply(r, n)
                }
                return r
            }

            function D(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var r = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? N(Object(r), !0).forEach((function(t) {
                        (0, b.Z)(e, t, r[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : N(Object(r)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(r, t))
                    }))
                }
                return e
            }
            var M = e => (0, u.jsxs)("svg", D(D({
                viewBox: "0 0 24 24"
            }, e), {}, {
                children: [(0, u.jsx)(O, {
                    shape: e.shape,
                    fill: "#00E676",
                    rx: 4
                }), (0, u.jsx)("path", {
                    d: "M16.201 7.746a5.9 5.9 0 0 0-4.205-1.745c-3.276 0-5.945 2.669-5.948 5.945 0 1.049.274 2.07.793 2.973L6 18.001l3.153-.826a5.95 5.95 0 0 0 2.843.724h.003c3.275 0 5.944-2.669 5.947-5.948A5.92 5.92 0 0 0 16.2 7.746m-4.205 9.146c-.89 0-1.76-.24-2.518-.69l-.18-.108-1.87.49.5-1.824-.118-.188a4.9 4.9 0 0 1-.755-2.63 4.95 4.95 0 0 1 4.944-4.937c1.32 0 2.56.516 3.495 1.448a4.92 4.92 0 0 1 1.445 3.496 4.95 4.95 0 0 1-4.943 4.943m2.711-3.7a27 27 0 0 0-1.015-.485c-.137-.049-.236-.074-.334.074-.1.148-.384.485-.47.582-.085.1-.174.11-.322.037s-.627-.231-1.195-.739a4.5 4.5 0 0 1-.827-1.029c-.085-.148-.008-.228.066-.302.066-.066.148-.174.223-.26.074-.085.1-.148.148-.248s.025-.185-.012-.259-.333-.807-.459-1.103c-.12-.291-.242-.251-.333-.254C10.09 9.2 9.99 9.2 9.892 9.2c-.1 0-.26.037-.397.185-.136.149-.519.508-.519 1.24 0 .733.534 1.438.608 1.537.074.1 1.046 1.6 2.537 2.244.354.154.63.245.847.314.356.114.678.097.935.06.285-.043.878-.36 1.004-.707.122-.348.122-.645.085-.707-.037-.063-.137-.1-.285-.174",
                    fill: "#fff"
                })]
            }));

            function T(e, t) {
                var r = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(e);
                    t && (n = n.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), r.push.apply(r, n)
                }
                return r
            }

            function _(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var r = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? T(Object(r), !0).forEach((function(t) {
                        (0, b.Z)(e, t, r[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : T(Object(r)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(r, t))
                    }))
                }
                return e
            }
            var A = e => (0, u.jsxs)("svg", _(_({
                viewBox: "0 0 24 24"
            }, e), {}, {
                children: [(0, u.jsx)(O, {
                    shape: e.shape,
                    fill: "#F1F1F1",
                    rx: 4
                }), (0, u.jsx)("path", {
                    d: "M12 6.002c-3.38 0-6 2.476-6 5.82 0 1.75.717 3.26 1.884 4.305a.48.48 0 0 1 .162.342l.032 1.067a.48.48 0 0 0 .674.424l1.19-.525a.48.48 0 0 1 .321-.024c.547.15 1.13.23 1.737.23 3.38 0 6-2.475 6-5.82 0-3.343-2.62-5.82-6-5.82",
                    fill: "url(#paint0_radial_657_559)"
                }), (0, u.jsx)("path", {
                    d: "m8.397 13.524 1.762-2.796a.9.9 0 0 1 1.302-.24l1.402 1.05a.36.36 0 0 0 .433 0L15.19 10.1c.252-.192.582.11.413.379l-1.763 2.796a.9.9 0 0 1-1.301.24l-1.402-1.051a.36.36 0 0 0-.434.001L8.81 13.903c-.252.191-.582-.11-.413-.38",
                    fill: "#fff"
                }), (0, u.jsx)("defs", {
                    children: (0, u.jsxs)("radialGradient", {
                        id: "paint0_radial_657_559",
                        cx: "0",
                        cy: "0",
                        r: "1",
                        gradientUnits: "userSpaceOnUse",
                        gradientTransform: "translate(8.3 17.9) scale(13 13)",
                        children: [(0, u.jsx)("stop", {
                            stopColor: "#0099FF"
                        }), (0, u.jsx)("stop", {
                            offset: "0.6",
                            stopColor: "#A033FF"
                        }), (0, u.jsx)("stop", {
                            offset: "0.93",
                            stopColor: "#FF5280"
                        }), (0, u.jsx)("stop", {
                            offset: "1",
                            stopColor: "#FF7061"
                        })]
                    })
                })]
            }));

            function U(e, t) {
                var r = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(e);
                    t && (n = n.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), r.push.apply(r, n)
                }
                return r
            }

            function I(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var r = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? U(Object(r), !0).forEach((function(t) {
                        (0, b.Z)(e, t, r[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : U(Object(r)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(r, t))
                    }))
                }
                return e
            }
            var R = e => (0, u.jsxs)("svg", I(I({
                viewBox: "0 0 48 48"
            }, e), {}, {
                children: [(0, u.jsx)(O, {
                    shape: e.shape,
                    fill: "#60696C",
                    rx: 8
                }), (0, u.jsx)("path", {
                    d: "M24.154 26.568a.5.5 0 0 0 .692 0l1.416-1.354 5.192 4.976a.5.5 0 0 0 .692-.722l-5.16-4.946 5.228-4.997a.5.5 0 0 0-.691-.723l-5.582 5.336-.048.045-1.393 1.332-1.386-1.325-.062-.059-5.575-5.329a.5.5 0 1 0-.691.723l5.229 4.998-5.162 4.947a.5.5 0 1 0 .695.721l5.19-4.976z",
                    fill: "#fff"
                }), (0, u.jsx)("path", {
                    d: "M35 29.318a3.683 3.683 0 0 1-3.679 3.68H17.679A3.683 3.683 0 0 1 14 29.317v-9.642a3.683 3.683 0 0 1 3.679-3.679h13.642A3.683 3.683 0 0 1 35 19.677zm-17.321-12.32A2.68 2.68 0 0 0 15 19.675v9.642a2.68 2.68 0 0 0 2.679 2.68h13.642A2.68 2.68 0 0 0 34 29.317v-9.642a2.68 2.68 0 0 0-2.679-2.679z",
                    fill: "#fff"
                })]
            }));

            function H(e, t) {
                var r = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(e);
                    t && (n = n.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), r.push.apply(r, n)
                }
                return r
            }

            function B(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var r = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? H(Object(r), !0).forEach((function(t) {
                        (0, b.Z)(e, t, r[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : H(Object(r)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(r, t))
                    }))
                }
                return e
            }
            var F = e => (0, u.jsxs)("svg", B(B({
                    viewBox: "0 0 24 24"
                }, e), {}, {
                    children: [(0, u.jsx)(O, {
                        shape: e.shape,
                        fill: "#FFFC00",
                        rx: 4
                    }), (0, u.jsx)("path", {
                        fill: "#fff",
                        d: "M18.78 15.392c-.058-.193-.337-.329-.337-.329l-.07-.036a5.4 5.4 0 0 1-1.224-.802 4.2 4.2 0 0 1-.71-.809 3 3 0 0 1-.391-.806c-.026-.104-.022-.146 0-.2a.3.3 0 0 1 .097-.11c.157-.111.41-.275.565-.375.135-.087.25-.162.318-.21.218-.152.368-.308.456-.476a.82.82 0 0 0 .039-.69c-.12-.317-.416-.505-.792-.505q-.126 0-.255.027c-.216.047-.42.124-.59.19a.018.018 0 0 1-.026-.018c.019-.423.04-.992-.008-1.533a3.8 3.8 0 0 0-.307-1.26 3.4 3.4 0 0 0-.548-.821 3.4 3.4 0 0 0-.867-.697 4 4 0 0 0-2.022-.515 4 4 0 0 0-2.02.515c-.45.257-.737.547-.868.697-.168.193-.383.46-.548.82s-.266.771-.307 1.261a12 12 0 0 0-.009 1.533c0 .014-.012.024-.026.018a4 4 0 0 0-.59-.19 1.2 1.2 0 0 0-.256-.027c-.375 0-.67.188-.791.505a.82.82 0 0 0 .039.69c.089.168.237.324.455.476.067.048.183.123.318.21.151.099.397.258.556.368a.3.3 0 0 1 .106.117c.023.055.027.097-.002.208a3 3 0 0 1-.39.798c-.19.29-.43.561-.709.809-.347.306-.76.577-1.224.802l-.077.04s-.278.142-.33.325c-.078.271.129.525.339.661.344.223.763.342 1.006.407q.102.027.185.052a.4.4 0 0 1 .16.093c.047.06.052.136.07.22.025.143.085.32.262.442.194.133.44.143.752.156.326.012.732.027 1.197.182.215.07.411.191.636.33.472.29 1.06.651 2.062.651 1.004 0 1.596-.362 2.07-.654.226-.137.419-.257.63-.326.465-.154.87-.17 1.197-.182.312-.012.558-.02.752-.156.19-.13.243-.325.268-.47.014-.072.023-.138.064-.19a.36.36 0 0 1 .154-.09q.085-.027.192-.055c.243-.065.548-.142.92-.351.446-.254.477-.565.43-.72Z"
                    }), (0, u.jsx)("path", {
                        fill: "#000",
                        d: "M19.168 15.242c-.1-.269-.288-.412-.502-.531a1 1 0 0 0-.108-.057l-.195-.099c-.667-.354-1.19-.801-1.55-1.33a3 3 0 0 1-.267-.472c-.03-.09-.03-.14-.007-.185a.3.3 0 0 1 .086-.089c.115-.076.233-.153.314-.204.143-.093.257-.167.329-.217.275-.191.466-.395.586-.623.17-.32.19-.688.06-1.032-.18-.478-.634-.775-1.18-.775q-.173 0-.344.038l-.089.02a10 10 0 0 0-.031-1.01c-.103-1.195-.521-1.82-.957-2.32a3.8 3.8 0 0 0-.974-.784A4.4 4.4 0 0 0 12.11 5c-.815 0-1.565.192-2.227.57a3.8 3.8 0 0 0-.975.785c-.436.499-.854 1.125-.957 2.32-.029.338-.036.685-.032 1.01l-.089-.02a1.6 1.6 0 0 0-.343-.038c-.547 0-1 .297-1.18.775-.13.344-.11.71.06 1.031.12.228.312.432.586.624.073.051.186.125.329.217.078.05.19.123.301.197a.3.3 0 0 1 .098.097c.023.047.023.098-.012.193-.058.13-.143.287-.262.462-.354.518-.861.957-1.507 1.307-.343.182-.698.303-.848.711-.114.308-.039.66.248.955q.14.152.364.275c.353.195.653.29.889.356a.6.6 0 0 1 .18.08c.105.092.09.23.23.434.084.126.182.212.262.268.293.202.624.215.973.229.316.012.674.026 1.082.16.17.056.346.165.549.29.489.301 1.16.712 2.28.712 1.122 0 1.795-.414 2.288-.715.203-.124.378-.232.542-.286.408-.135.766-.149 1.082-.161.35-.014.678-.027.973-.23.092-.063.208-.167.3-.326.1-.17.099-.291.193-.373a.6.6 0 0 1 .17-.077 4 4 0 0 0 .9-.36c.16-.087.284-.183.382-.292l.005-.004c.267-.292.336-.632.224-.934m-.996.535c-.608.336-1.012.3-1.326.501-.267.173-.11.543-.303.677-.239.165-.943-.011-1.852.288-.75.249-1.23.961-2.58.961-1.354 0-1.82-.71-2.58-.96-.91-.3-1.615-.124-1.853-.29-.193-.133-.036-.503-.303-.676-.313-.202-.718-.166-1.326-.501-.387-.214-.168-.346-.039-.408 2.203-1.065 2.553-2.712 2.57-2.836.019-.147.04-.264-.123-.415-.157-.146-.855-.578-1.048-.712-.321-.224-.461-.447-.357-.722.072-.19.25-.261.437-.261q.089 0 .175.019c.352.076.693.253.89.3q.042.01.073.01c.105 0 .141-.053.134-.174-.022-.385-.078-1.134-.016-1.836.083-.963.394-1.441.763-1.865.178-.202 1.011-1.083 2.604-1.083 1.597 0 2.426.88 2.604 1.083.369.423.68.9.763 1.865.061.702.009 1.451-.016 1.836-.009.126.03.174.134.174a.3.3 0 0 0 .073-.01c.197-.047.538-.224.89-.3a1 1 0 0 1 .175-.02c.187 0 .365.073.437.262.104.275-.037.498-.357.722-.193.134-.891.566-1.048.712-.163.15-.142.267-.122.415.015.124.366 1.77 2.569 2.836.125.062.345.194-.042.408"
                    })]
                })),
                z = r(7661),
                Z = r.n(z),
                K = r(11479),
                V = r.n(K),
                q = r(28417);

            function W(e, t) {
                var r = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(e);
                    t && (n = n.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), r.push.apply(r, n)
                }
                return r
            }

            function G(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var r = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? W(Object(r), !0).forEach((function(t) {
                        (0, b.Z)(e, t, r[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : W(Object(r)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(r, t))
                    }))
                }
                return e
            }

            function Y(e, t) {
                var r = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(e);
                    t && (n = n.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), r.push.apply(r, n)
                }
                return r
            }

            function $(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var r = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? Y(Object(r), !0).forEach((function(t) {
                        (0, b.Z)(e, t, r[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : Y(Object(r)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(r, t))
                    }))
                }
                return e
            }

            function X(e, t) {
                var r = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(e);
                    t && (n = n.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), r.push.apply(r, n)
                }
                return r
            }

            function J(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var r = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? X(Object(r), !0).forEach((function(t) {
                        (0, b.Z)(e, t, r[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : X(Object(r)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(r, t))
                    }))
                }
                return e
            }
            var Q = e => (0, u.jsxs)("svg", J(J({
                viewBox: "0 0 48 48"
            }, e), {}, {
                children: [(0, u.jsx)("circle", {
                    cx: "50%",
                    cy: "50%",
                    r: "50%",
                    fill: "#E0E2D9"
                }), (0, u.jsx)("path", {
                    d: "m23.863 18.214-.422.489-.757-.654.434-.503.025-.027a5.19 5.19 0 1 1 7.337 7.34l-.025.023-.5.435-.657-.755.487-.423a4.19 4.19 0 0 0-5.922-5.925m3.654 2.975-.354.354-5.626 5.626-.353.353-.708-.707.354-.353 5.626-5.627.354-.353zm-8.81 2.25-.481.425a4.16 4.16 0 0 0 .01 5.91 4.25 4.25 0 0 0 5.953.026l.349-.47.802.597-.372.5-.05.058a5.25 5.25 0 0 1-7.385 0 5.16 5.16 0 0 1 0-7.342l.02-.02.491-.433z"
                })]
            }));

            function ee(e, t) {
                var r = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(e);
                    t && (n = n.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), r.push.apply(r, n)
                }
                return r
            }

            function te(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var r = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? ee(Object(r), !0).forEach((function(t) {
                        (0, b.Z)(e, t, r[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : ee(Object(r)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(r, t))
                    }))
                }
                return e
            }

            function re(e, t) {
                var r = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(e);
                    t && (n = n.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), r.push.apply(r, n)
                }
                return r
            }

            function ne(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var r = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? re(Object(r), !0).forEach((function(t) {
                        (0, b.Z)(e, t, r[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : re(Object(r)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(r, t))
                    }))
                }
                return e
            }
            const oe = ["type"];

            function le(e, t) {
                var r = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(e);
                    t && (n = n.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), r.push.apply(r, n)
                }
                return r
            }
            const ce = {
                    facebook: g,
                    linkedin: w,
                    twitter: E,
                    x: L,
                    whatsapp: M,
                    messenger: A,
                    email: R,
                    snapchat: F,
                    moreOptions: e => {
                        const {
                            isAndroid: t
                        } = (0, q.Z)();
                        return (0, u.jsxs)("svg", G(G({
                            viewBox: "0 0 48 48"
                        }, e), {}, {
                            children: [(0, u.jsx)(O, {
                                shape: e.shape,
                                fill: "#E0E2D9",
                                rx: 8
                            }), (0, u.jsx)("svg", {
                                viewBox: "circle" === e.shape ? "-16 -16 48 48" : "-10 -10 36 36",
                                children: t ? (0, u.jsx)(V(), {}) : (0, u.jsx)(Z(), {})
                            })]
                        }))
                    },
                    openLink: e => (0, u.jsxs)("svg", $($({
                        viewBox: "0 0 48 48"
                    }, e), {}, {
                        children: [(0, u.jsx)("circle", {
                            cx: "50%",
                            cy: "50%",
                            r: "50%",
                            fill: "#E0E2D9"
                        }), (0, u.jsx)("path", {
                            d: "M24.5 16.999H31v6.5h-1v-4.793l-6.646 6.646-.708-.707L29.293 18H24.5zM17 19h4v1h-3v9.999l1.346.001H28v-3h1v3.999h-.5L27.154 31h-7.808l-1.846-.001H17z"
                        })]
                    })),
                    copyLink: Q,
                    copyLinktree: Q,
                    success: e => (0, u.jsxs)("svg", te(te({
                        viewBox: "0 0 48 48"
                    }, e), {}, {
                        children: [(0, u.jsx)("circle", {
                            cx: "50%",
                            cy: "50%",
                            r: "50%",
                            fill: "#E0E2D9"
                        }), (0, u.jsx)("path", {
                            d: "m30.702 18.51-.313.39-8 10-.764.02-4-4.5-.332-.374.747-.664.333.374 3.606 4.057 7.63-9.538.312-.39z",
                            fill: "#016e1a"
                        })]
                    })),
                    reportLinktree: e => (0, u.jsxs)("svg", ne(ne({
                        viewBox: "0 0 48 48"
                    }, e), {}, {
                        children: [(0, u.jsx)("circle", {
                            cx: "50%",
                            cy: "50%",
                            r: "50%",
                            fill: "#E0E2D9"
                        }), (0, u.jsx)("path", {
                            fillRule: "evenodd",
                            d: "M18 16v16h1v-7h11.5l.38-.825L28.158 21l2.722-3.175L30.5 17H19v-1zm1 2v6h10.413l-2.293-2.675v-.65L29.413 18z"
                        })]
                    }))
                },
                ae = e => {
                    let {
                        type: t
                    } = e;
                    const r = ce[t];
                    return r ? (0, u.jsx)(r, {
                        className: "h-12 w-12",
                        "data-testid": "ShareIcon-".concat(t),
                        shape: "circle"
                    }) : null
                };
            var ie = e => {
                let {
                    type: t
                } = e, r = (0, v.Z)(e, oe);
                return (0, u.jsx)(ae, function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var r = null != arguments[t] ? arguments[t] : {};
                        t % 2 ? le(Object(r), !0).forEach((function(t) {
                            (0, b.Z)(e, t, r[t])
                        })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : le(Object(r)).forEach((function(t) {
                            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(r, t))
                        }))
                    }
                    return e
                }({
                    type: t
                }, r))
            };
            const se = "Check out this Linktree!",
                ue = e => encodeURIComponent(e || se),
                de = e => {
                    let {
                        shareUrl: t
                    } = e;
                    return t
                },
                pe = {
                    copyLink: {
                        label: "Copy link",
                        shortLabel: "Copy link",
                        generateUrl: de
                    },
                    copyLinktree: {
                        label: "Copy Linktree",
                        shortLabel: "Copy Linktree",
                        generateUrl: de
                    },
                    x: {
                        label: "Share on X",
                        shortLabel: "X",
                        generateUrl: e => {
                            let {
                                shareUrl: t,
                                title: r
                            } = e;
                            return "https://x.com/intent/tweet?text=".concat(ue(r), " - ").concat(t)
                        }
                    },
                    facebook: {
                        label: "Share on Facebook",
                        shortLabel: "Facebook",
                        generateUrl: e => {
                            let {
                                shareUrl: t
                            } = e;
                            return "https://www.facebook.com/sharer.php?u=".concat(t)
                        }
                    },
                    whatsapp: {
                        label: "Share via WhatsApp",
                        shortLabel: "WhatsApp",
                        generateUrl: e => {
                            let {
                                shareUrl: t,
                                title: r
                            } = e;
                            return "https://wa.me/?text=".concat(ue(r), " - ").concat(t)
                        }
                    },
                    linkedin: {
                        label: "Share on LinkedIn",
                        shortLabel: "LinkedIn",
                        generateUrl: e => {
                            let {
                                shareUrl: t
                            } = e;
                            return "https://www.linkedin.com/sharing/share-offsite/?url=".concat(t)
                        }
                    },
                    messenger: {
                        label: "Share via Messenger",
                        shortLabel: "Messenger",
                        generateUrl: () => "https://www.messenger.com/new"
                    },
                    snapchat: {
                        label: "Share on Snapchat",
                        shortLabel: "Snapchat",
                        generateUrl: e => {
                            let {
                                shareUrl: t
                            } = e;
                            return "snapchat://creativeKitWeb/camera/1?attachmentUrl=".concat(encodeURI(t.split(/[?#]/)[0]))
                        }
                    },
                    email: {
                        label: "Share via Email",
                        shortLabel: "Email",
                        generateUrl: e => {
                            let {
                                shareUrl: t,
                                title: r
                            } = e;
                            return "mailto:?subject= ".concat(se, " &body= ").concat(ue(r), " - ").concat(t)
                        }
                    },
                    moreOptions: {
                        label: "More options",
                        shortLabel: "More",
                        generateUrl: de
                    }
                };
            let fe, he;
            ! function(e) {
                e.FACEBOOK = "facebook", e.LINKEDIN = "linkedin", e.TWITTER = "twitter", e.X = "x", e.WHATSAPP = "whatsapp", e.MESSENGER = "messenger", e.EMAIL = "email", e.SNAPCHAT = "snapchat", e.MORE_OPTIONS = "moreOptions", e.COPY_LINK = "copyLink", e.COPY_LINKTREE = "copyLinktree", e.OPEN_LINK = "openLink", e.SUCCESS = "success", e.REPORT_LINKTREE = "reportLinktree"
            }(fe || (fe = {})),
            function(e) {
                e.LINK = "ShareModalLink", e.ACCOUNT = "ShareModalAccount", e.COMMERCE_COLLECTION = "ShareModalCommerceCollection", e.COMMERCE_PRODUCT = "ShareModalCommerceProduct"
            }(he || (he = {}));
            var be = r(95647),
                ve = r(49344),
                Oe = r(82609),
                je = r.n(Oe),
                me = r(93967),
                ge = r.n(me);
            var xe = e => {
                    let {
                        onClick: t,
                        direction: r,
                        visible: n
                    } = e;
                    return (0, u.jsx)("button", {
                        type: "button",
                        className: ge()("h-11 w-11 p-3 rounded-full border", "z-10 flex absolute items-center justify-center top-[3px] shadow-low-elevation-light hover:bg-chalk", {
                            "left-3": "left" === r,
                            "right-3": "right" === r,
                            invisible: !n
                        }),
                        style: {
                            borderColor: "var(--light-border-or-divider, #e0e2d9)",
                            backgroundColor: "var(--light-container, #fff)"
                        },
                        onClick: t,
                        children: (0, u.jsx)(je(), {
                            direction: r
                        })
                    })
                },
                ye = r(23493),
                we = r.n(ye);

            function Pe(e, t) {
                var r = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(e);
                    t && (n = n.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), r.push.apply(r, n)
                }
                return r
            }

            function ke(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var r = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? Pe(Object(r), !0).forEach((function(t) {
                        (0, b.Z)(e, t, r[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : Pe(Object(r)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(r, t))
                    }))
                }
                return e
            }
            const Ee = (e, t) => {
                const r = ke({}, pe);
                return t === he.ACCOUNT ? delete r.copyLink : delete r.copyLinktree, e || delete r.snapchat, navigator.share || delete r.moreOptions, r
            };
            var Se = e => {
                    var t;
                    let {
                        shareUrl: r,
                        closeModal: o,
                        modalType: l,
                        url: c,
                        className: a
                    } = e;
                    const {
                        account: s
                    } = (0, i.EG)(), d = null !== (t = null === s || void 0 === s ? void 0 : s.isSnapchatSocialShareEnabled) && void 0 !== t && t, p = Ee(d, l), f = (0, n.useRef)(null), {
                        0: h,
                        1: b
                    } = (0, n.useState)(!1), {
                        0: v,
                        1: O
                    } = (0, n.useState)(!1), {
                        0: j,
                        1: m
                    } = (0, n.useState)(!0), g = (0, ve.tq)() ? 4 : 24;
                    (0, n.useEffect)((() => {
                        if ("undefined" !== typeof window.snap) try {
                            window.snap.creativekit.initalizeShareButtons(document.getElementsByClassName("snapchat-share-button"))
                        } catch (e) {
                            (0, be.c)("error", "Failed to initialise Snapchat share button", {
                                origin: "ShareModal",
                                squad: "Top-of-Funnel"
                            })
                        }
                    }), []), (0, n.useEffect)((() => {
                        x();
                        const e = null === f || void 0 === f ? void 0 : f.current,
                            t = we()((() => x()), 100);
                        return e && (e.removeEventListener("scroll", t), e.addEventListener("scroll", t, {
                            passive: !0
                        })), () => window.removeEventListener("scroll", t)
                    }), []);
                    const x = () => {
                        const e = null === f || void 0 === f ? void 0 : f.current;
                        e && (O(e.scrollLeft > 0), m(e.scrollLeft < e.scrollWidth - e.clientWidth - g))
                    };
                    return (0, u.jsx)("div", {
                        className: ge()("flex flex-col gap-4 self-stretch py-6", a),
                        "data-testid": "ShareModal-ShareList",
                        onPointerEnter: e => {
                            "mouse" === e.pointerType && b(!0)
                        },
                        onPointerLeave: () => b(!1),
                        children: (0, u.jsxs)("div", {
                            className: ge()("relative", a),
                            children: [!(0, ve.tq)() && h && (0, u.jsxs)("div", {
                                children: [(0, u.jsx)(xe, {
                                    onClick: () => {
                                        const e = null === f || void 0 === f ? void 0 : f.current;
                                        e && (e.scrollBy({
                                            top: 0,
                                            left: -e.scrollLeft,
                                            behavior: "smooth"
                                        }), x())
                                    },
                                    direction: "left",
                                    visible: v
                                }), (0, u.jsx)(xe, {
                                    onClick: () => {
                                        const e = null === f || void 0 === f ? void 0 : f.current;
                                        if (e) {
                                            const t = e.scrollWidth - e.clientWidth - e.scrollLeft;
                                            e.scrollBy({
                                                top: 0,
                                                left: t,
                                                behavior: "smooth"
                                            }), x()
                                        }
                                    },
                                    direction: "right",
                                    visible: j
                                })]
                            }), (0, u.jsx)("div", {
                                className: "flex items-start gap-4 overflow-auto pl-4 webkit-scrollbar:w-0 webkit-scrollbar:bg-transparent",
                                ref: f,
                                style: {
                                    paddingRight: "".concat(g + 16, "px")
                                },
                                children: Object.entries(p).map((e => {
                                    let [t, n] = e;
                                    return (0, u.jsx)(_e, ke({
                                        shareUrl: r,
                                        shareType: t,
                                        closeModal: o,
                                        url: c
                                    }, n), t)
                                }))
                            })]
                        })
                    })
                },
                Ce = r(49518),
                Le = r(94686);
            const Ne = e => {
                let {
                    trackEvent: t,
                    metadata: r
                } = e;
                t("ReportLinktreeCtaClicked", r, {
                    contexts: {
                        linktree: {
                            ctxVersion: "1-0-3",
                            properties: {
                                version: "1-0-0",
                                squad: Le.LinktreeSquad.TopOfFunnel,
                                feature: "Report this Linktree CTA"
                            }
                        },
                        account: {
                            ctxVersion: "1-0-0"
                        },
                        browser: {
                            ctxVersion: "1-0-0"
                        }
                    }
                })
            };
            var De = async (e, t) => {
                if (navigator.share) try {
                    await navigator.share({
                        title: "".concat(e, " | Linktree"),
                        url: t
                    })
                } catch (n) {
                    var r;
                    const {
                        name: e,
                        message: t
                    } = null !== (r = n) && void 0 !== r ? r : {};
                    if ("AbortError" === e) return;
                    (0, be.c)("error", "Error on share profile click", {
                        squad: "Delight-Knights",
                        origin: "TopBar.handleWebShareAPIClick",
                        context: {
                            error: {
                                name: e,
                                message: t
                            }
                        }
                    })
                }
            };

            function Me(e, t) {
                var r = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(e);
                    t && (n = n.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), r.push.apply(r, n)
                }
                return r
            }

            function Te(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var r = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? Me(Object(r), !0).forEach((function(t) {
                        (0, b.Z)(e, t, r[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : Me(Object(r)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(r, t))
                    }))
                }
                return e
            }
            var _e = e => {
                    let {
                        shareUrl: t,
                        url: r,
                        shareType: o,
                        shortLabel: l,
                        generateUrl: c,
                        closeModal: s
                    } = e;
                    const {
                        linkId: d,
                        linkTitle: p
                    } = (0, a.lB)(), {
                        trackShareAction: f
                    } = (0, Ce.o)(d), {
                        title: h,
                        account: b,
                        trackV2Event: v
                    } = (0, i.EG)(), O = c({
                        url: r,
                        shareUrl: t,
                        title: p,
                        username: null === b || void 0 === b ? void 0 : b.username
                    }), j = o === fe.SNAPCHAT, m = o === fe.MORE_OPTIONS || o === fe.COPY_LINK || o === fe.COPY_LINKTREE, {
                        0: g,
                        1: x
                    } = (0, n.useState)(o), {
                        0: y,
                        1: w
                    } = (0, n.useState)(!1);
                    (0, n.useEffect)((() => {
                        y && setTimeout((() => {
                            w(!1), x(o)
                        }), 1e3)
                    }), [y]);
                    const P = Te({}, j && {
                            "data-share-url": t.split(/[?#]/)[0]
                        }),
                        k = m ? "button" : "a";
                    return (0, u.jsx)("div", {
                        className: "flex w-[60px]",
                        children: (0, u.jsxs)(k, Te(Te(Te({
                            className: ge()("flex w-[60px] flex-col items-center justify-center gap-2 px-[3px] outline-none focus-visible:ring-1 focus-visible:ring-black", {
                                "snapchat-share-button": j
                            })
                        }, m ? {
                            type: "button"
                        } : {
                            target: "_blank",
                            href: O
                        }), {}, {
                            onClick: (e => o === fe.MORE_OPTIONS ? async () => {
                                f(o, e), s(), await De(p || h, O)
                            } : o === fe.COPY_LINK || o === fe.COPY_LINKTREE ? async () => {
                                f(o, e), await (async () => {
                                    try {
                                        await navigator.clipboard.writeText(t).then((() => {
                                            w(!0), x(fe.SUCCESS)
                                        }))
                                    } catch (e) {
                                        console.error("Failed to copy to clipboard: ", e)
                                    }
                                })()
                            } : o === fe.REPORT_LINKTREE ? async () => {
                                Ne({
                                    trackEvent: v,
                                    metadata: {
                                        placement: "Meatball Menu",
                                        callToActionText: l,
                                        callToActionLink: O
                                    }
                                })
                            } : () => {
                                f(o, e)
                            })(d),
                            "data-testid": "ShareModal-ShareLink"
                        }, P), {}, {
                            children: [(0, u.jsx)("div", {
                                className: "bg-neutral-200 relative flex h-12 w-12 items-center justify-center rounded-[320px]",
                                children: (0, u.jsx)(ie, {
                                    type: g
                                })
                            }), y ? (0, u.jsx)("div", {
                                className: "whitespace-nowrap text-center text-xs text-success",
                                color: '#016E1A"',
                                children: "Copied"
                            }) : (0, u.jsx)("div", {
                                className: "whitespace-nowrap text-center text-xs",
                                children: l
                            })]
                        }))
                    })
                },
                Ae = r(25185),
                Ue = r.n(Ae),
                Ie = r(15468),
                Re = r.n(Ie),
                He = r(757);
            var Be = async (e, t) => {
                if (e) {
                    const r = await f().post("".concat(t || "", "/api/profiles/link-preview/image-bg-color"), {
                        imageUrl: e
                    });
                    if (200 == r.status) return r.data
                }
            };
            var Fe = r(66963);
            const ze = "#F3F3F1";
            var Ze = e => {
                    let {
                        url: t,
                        imageUrl: r,
                        thumbnail: l,
                        title: c,
                        description: a,
                        locked: s,
                        metaData: d,
                        isOpen: p,
                        handleLinkClick: f,
                        commerceStoreProductUuid: h
                    } = e;
                    const {
                        t: b
                    } = (0, o.$G)("MeatballMenu"), {
                        environment: {
                            PROFILES_API_HOST: v
                        } = {}
                    } = (0, i.EG)(), {
                        0: O,
                        1: j
                    } = (0, n.useState)(!0 === s), {
                        0: m,
                        1: g
                    } = (0, n.useState)(r || l), x = s || !m || m.endsWith(".svg"), y = (e => {
                        if (!e) return {
                            url: e,
                            length: 0
                        };
                        try {
                            e = e.replace(/(^\w+:|^)\/\//, "");
                            const t = /(?:\w+\.)+\w+/gm;
                            if (t.test(e)) {
                                const r = e.match(t)[0],
                                    n = e.indexOf(r);
                                return {
                                    url: e,
                                    length: Math.min(n + r.length + 4, e.length)
                                }
                            }
                        } catch (t) {
                            return {
                                url: e,
                                length: e.length
                            }
                        }
                        return {
                            url: e,
                            length: e.length
                        }
                    })(t), {
                        0: w,
                        1: P
                    } = (0, n.useState)(x ? 0 : 1), {
                        0: k,
                        1: E
                    } = (0, n.useState)(ze), {
                        0: S,
                        1: C
                    } = (0, n.useState)(!0), L = w > 0 || S, N = L ? ze : k, D = h ? {
                        url: String(t),
                        id: h,
                        accountProductId: h,
                        title: c,
                        salePrice: void 0
                    } : {}, M = (0, Fe.Z)(D);
                    let T = a || "";
                    s && (T = "This link is locked and can only be accessed by fulfilling certain criteria.");
                    const _ = T.length > 130 && !s,
                        A = () => {
                            const e = (0, He.oo)(N);
                            return e && .299 * e[0] + .587 * e[1] + .114 * e[2] <= 186 ? "white" : "black"
                        },
                        U = "black" === A() ? "rgba(0, 0, 0, 0.10)" : "rgba(252, 250, 248, 0.10)";
                    (0, n.useEffect)((() => {
                        if (p) {
                            (async () => {
                                if (!x && m) {
                                    const e = await Be(m, v);
                                    e && E(e)
                                }
                            })().catch((e => {
                                var t;
                                console.error("Error fetching image background color: ", e), null !== (t = e.response) && void 0 !== t && t.data && console.error("Fetch response error:", e.response.data)
                            })).finally((() => {
                                P((e => e - 1))
                            }))
                        }
                    }), [m, p]);
                    const I = t ? "a" : "div";
                    return (0, u.jsx)("div", {
                        className: "inline-flex w-full justify-center px-5",
                        children: (0, u.jsx)(I, {
                            "data-testid": "ShareModal-LinkPreview",
                            className: ge()("w-full flex-col rounded-lg p-6 shadow-low-elevation-light md:w-[327px]", {
                                "hover:scale-[1.01] hover:shadow-max-elevation-light": t
                            }),
                            style: {
                                border: "1px solid gainsboro",
                                backgroundColor: N,
                                transition: "transform 250ms ease-in-out, box-shadow 250ms ease-in-out, background-color 700ms linear"
                            },
                            href: t,
                            target: "_blank",
                            onClick: () => {
                                h ? null === M || void 0 === M || M() : t && (null === f || void 0 === f || f())
                            },
                            children: (0, u.jsxs)("div", {
                                className: "flex flex-col items-center justify-center gap-4 self-stretch",
                                children: [p ? s ? (0, u.jsx)(Ue(), {}) : m ? (0, u.jsxs)("div", {
                                    className: "inline-flex h-[120px] w-[120px] items-center justify-center",
                                    children: [L && (0, u.jsx)(Re(), {}), (0, u.jsx)("img", {
                                        className: "h-full w-full rounded-sm object-cover ".concat(L ? "hidden" : ""),
                                        src: m,
                                        alt: (null === d || void 0 === d ? void 0 : d.imageAlt) || "link preview image",
                                        onLoad: () => {
                                            C(!1)
                                        },
                                        onError: () => {
                                            m === r && l ? (g(l), C(!0), P((e => e + 1))) : (g(void 0), C(!1))
                                        }
                                    })]
                                }) : null : null, (0, u.jsxs)("div", {
                                    className: "flex flex-col items-center justify-center gap-2 self-stretch",
                                    children: [(0, u.jsx)("h3", {
                                        className: "text-center leading-normal",
                                        style: {
                                            color: A(),
                                            fontSize: "20px",
                                            fontWeight: "800",
                                            lineHeight: "120%",
                                            textWrap: "balance"
                                        },
                                        children: c
                                    }), y.url && (0, u.jsx)("p", {
                                        style: {
                                            color: A(),
                                            fontSize: "13px",
                                            width: "min(90%, ".concat(y.length, "ch)"),
                                            lineHeight: "150%"
                                        },
                                        className: "overflow-hidden text-ellipsis whitespace-nowrap text-center",
                                        children: y.url
                                    })]
                                }), T && (0, u.jsxs)("div", {
                                    className: "flex flex-col items-center gap-2",
                                    children: [(0, u.jsx)("p", {
                                        style: {
                                            color: A(),
                                            fontSize: "12px",
                                            overflowWrap: "anywhere",
                                            textWrap: "balance"
                                        },
                                        className: "items-center overflow-hidden break-words text-center ".concat(O ? "line-clamp-none" : "line-clamp-3"),
                                        children: T
                                    }), _ && p && (0, u.jsx)("button", {
                                        onClick: e => {
                                            e.preventDefault(), j(!O)
                                        },
                                        className: "inline-flex h-7 w-16 items-center justify-center gap-[9.89px] rounded-xl px-[14.84px] hover:backdrop-contrast-75",
                                        style: {
                                            backgroundColor: U
                                        },
                                        children: (0, u.jsx)("span", {
                                            style: {
                                                color: A()
                                            },
                                            className: "text-stone-50 font-medium font-['Link Sans v2.0 Variable'] text-center text-xs leading-[13.20px]",
                                            children: b(O ? "lessButtonText" : "moreButtonText")
                                        })
                                    })]
                                })]
                            })
                        })
                    })
                },
                Ke = r(2740);
            var Ve = async (e, t, r) => {
                    try {
                        var n, o, l, c;
                        const a = await f().post("/api/profiles/short-link/get-or-create-commerce", {
                            accountUuid: e,
                            uuid: t,
                            type: r
                        });
                        return {
                            linkUuid: null !== (n = null === a || void 0 === a || null === (o = a.data) || void 0 === o ? void 0 : o.linkUuid) && void 0 !== n ? n : null,
                            shortId: null !== (l = null === a || void 0 === a || null === (c = a.data) || void 0 === c ? void 0 : c.shortId) && void 0 !== l ? l : null
                        }
                    } catch (a) {
                        return console.error("Failed to get or create commerce short link:", a), {
                            linkUuid: null,
                            shortId: null
                        }
                    }
                },
                qe = r(94736),
                We = r(31215),
                Ge = r(10650),
                Ye = r.n(Ge),
                $e = r(19685),
                Xe = r.n($e),
                Je = r(57497),
                Qe = r.n(Je),
                et = r(28502),
                tt = r.n(et),
                rt = r(76135),
                nt = r(83480),
                ot = r(28448);
            var lt = e => {
                    let {
                        username: t,
                        modalType: r
                    } = e;
                    const {
                        trackEvent: n
                    } = (0, i.EG)(), l = (0, ot.nV)(), c = (0, nt.v)(), {
                        t: a
                    } = (0, o.$G)("SignupOption", {
                        lng: c
                    }), s = a("titleText"), d = a("subTitleText"), p = a("signupCtaText"), f = a("homePageCtaText"), h = new URLSearchParams({
                        utm_source: "linktree",
                        utm_medium: "profile",
                        utm_content: t || "",
                        utm_campaign: r,
                        tofexp: "ShareModalVariant"
                    }), b = "".concat(rt.NJ.LINKTREE_SIGNUP, "?").concat(h.toString(), "&cta=getstartedforfree"), v = "".concat(rt.NJ.LINKTREE, "?").concat(h.toString(), "&cta=findoutmore");
                    if (null !== l && void 0 !== l && l.loading) return null;
                    const O = p.length <= 18 && f.length <= 18;
                    return (0, u.jsxs)("div", {
                        className: "relative flex flex-col items-stretch border-t border-solid border-t-pebble bg-white p-5",
                        "data-testid": "ShareModal-SignupOption",
                        children: [(0, u.jsxs)("div", {
                            className: "pb-4",
                            children: [(0, u.jsx)(Qe(), {
                                children: s
                            }), (0, u.jsx)(tt(), {
                                variant: "secondary",
                                className: "!text-sm",
                                children: d
                            })]
                        }), (0, u.jsxs)("div", {
                            className: "flex ".concat(O ? "flex-row" : "flex-col", " gap-2"),
                            children: [(0, u.jsx)("div", {
                                className: "w-full",
                                children: (0, u.jsx)(Ye(), {
                                    label: p,
                                    link: {
                                        href: b,
                                        target: "_blank"
                                    },
                                    onClick: () => {
                                        n("ProfileSignupCtaClicked", {
                                            callToActionText: p,
                                            callToActionLink: b,
                                            placement: "Meatball Menu CTA",
                                            campaign: r
                                        })
                                    },
                                    state: "default",
                                    className: "w-full !bg-black",
                                    "data-testid": "ShareModal-SignupButton"
                                })
                            }), (0, u.jsx)("div", {
                                className: "w-full",
                                children: (0, u.jsx)(Xe(), {
                                    label: f,
                                    link: {
                                        href: v,
                                        target: "_blank"
                                    },
                                    onClick: () => {
                                        n("ProfileSignupCtaClicked", {
                                            callToActionText: f,
                                            callToActionLink: v,
                                            placement: "Meatball Menu CTA",
                                            campaign: r
                                        })
                                    },
                                    state: "default",
                                    "data-testid": "ShareModal-HomePageButton",
                                    className: "w-full border-solid"
                                })
                            })]
                        })]
                    })
                },
                ct = r(55509),
                at = r.n(ct);
            var it = e => {
                const {
                    trackV2Event: t
                } = (0, i.EG)(), {
                    t: r
                } = (0, o.$G)("MeatballMenu"), n = r("reportLinktree"), l = (e => {
                    let {
                        url: t,
                        username: r,
                        title: n
                    } = e;
                    const o = new URL("https://linktr.ee/s/about/trust-center/report/");
                    return r && o.searchParams.set("field86145911", "https://linktr.ee/".concat(r)), (t || n) && o.searchParams.set("field155172010", t || n), o.toString()
                })(e);
                return (0, u.jsxs)("a", {
                    target: "_blank",
                    onClick: () => {
                        Ne({
                            trackEvent: t,
                            metadata: {
                                placement: "Meatball Menu",
                                callToActionText: n,
                                callToActionLink: l
                            }
                        })
                    },
                    className: "flex w-full items-center gap-2 border-t-[1px] border-solid border-t-sand p-6 text-concrete hover:bg-marble",
                    href: l,
                    rel: "noopener noreferrer",
                    children: [(0, u.jsx)(at(), {}), (0, u.jsx)("p", {
                        className: "font-semibold",
                        children: n
                    })]
                })
            };
            const st = e => {
                let {
                    isOpen: t,
                    children: r
                } = e;
                const {
                    isTestMode: o
                } = {
                    isTestMode: (0, n.useMemo)((() => !1), [])
                };
                return o ? null : (0, u.jsx)(Ke.h, {
                    children: (0, u.jsx)(u.Fragment, {
                        children: (0, u.jsx)("div", {
                            onClick: e => {
                                e.stopPropagation()
                            },
                            onMouseDown: e => {
                                e.stopPropagation()
                            },
                            "data-testid": "ModalOverlay",
                            className: ge()("fixed inset-0 z-[10020] flex items-end justify-center bg-black/60 p-0 font-sans sm:items-center", {
                                block: t
                            }),
                            style: {
                                display: t ? "flex" : "none"
                            },
                            children: (0, u.jsx)("div", {
                                "data-testid": "ShareModalContainer",
                                className: "h-auto max-h-full w-full overflow-y-auto sm:max-w-[348px] md:max-w-[520px]",
                                children: r
                            })
                        })
                    })
                })
            };
            var ut = e => {
                var t;
                const {
                    linkId: r,
                    url: p,
                    isOpen: f,
                    onClose: b,
                    trackingUuid: v,
                    locked: O,
                    thumbnail: j,
                    metaData: m,
                    commerceStoreProductUuid: g,
                    commerceCollectionUuid: x,
                    handleLinkClick: y,
                    customTitle: w
                } = e, {
                    account: P,
                    stage: k,
                    environment: E
                } = (0, i.EG)(), S = new l.InstrumentationEventPublisher(E.INGRESS_API_INSTRUMENTATION_ENDPOINT), {
                    0: C,
                    1: L
                } = (0, n.useState)(""), N = s(k), D = v && "?utm_source=linktree_profile_share&ltsid=".concat(v), M = null !== P && void 0 !== P && P.username ? "".concat(N, "/").concat(P.username).concat(D || "") : N, {
                    linkTitle: T,
                    context: _,
                    linkType: A
                } = (0, a.lB)(), U = "COMMERCE_PRODUCT" === A ? null === _ || void 0 === _ || null === (t = _.product) || void 0 === t ? void 0 : t.title : "", {
                    0: I,
                    1: R
                } = (0, n.useState)(!0), [H] = (0, qe.useStorage)("browserId", ""), [B] = (0, qe.useStorage)("sessionId", ""), F = (0, n.useMemo)((() => r ? he.LINK : g ? he.COMMERCE_PRODUCT : x ? he.COMMERCE_COLLECTION : he.ACCOUNT), [r, g, x]), {
                    t: z
                } = (0, o.$G)(F), Z = z("title");
                (0, n.useEffect)((() => {
                    if (f && null !== P && void 0 !== P && P.uuid) {
                        (async () => {
                            if (r) {
                                const e = await h(P.uuid, r);
                                L(null === e || void 0 === e ? void 0 : e.sourceUrl)
                            } else if (g || x) {
                                const e = g || x,
                                    t = g ? "PRODUCT" : "COLLECTION",
                                    r = await Ve(P.uuid, String(e), t);
                                if (null !== r && void 0 !== r && r.shortId) return void L("https://".concat("qa" === k ? "qa." : "", "tr.ee/").concat(r.shortId))
                            }
                        })().catch(console.error)
                    }
                }), [f, r, g, x, P, k]), (0, n.useEffect)((() => {
                    let e;
                    return f && (e = setTimeout((() => {
                        var e;
                        S.publishInstrumentationEvent(new c.N({
                            version: "2-0-0",
                            payload: {
                                browserId: H,
                                sessionId: B,
                                context: (0, We.buildPayloadContext)(),
                                eventType: "ProfileSignupCtaViewed",
                                data: {
                                    visits: 0,
                                    callToActionText: "share modal",
                                    placement: "Meatball Menu CTA",
                                    visitedAccountUuid: null !== (e = null === P || void 0 === P ? void 0 : P.uuid) && void 0 !== e ? e : "",
                                    visitedAccountId: null !== P && void 0 !== P && P.id ? String(P.id) : ""
                                }
                            }
                        }))
                    }), 500)), () => {
                        e && clearTimeout(e)
                    }
                }), [f]);
                const K = F === he.LINK,
                    V = F === he.COMMERCE_PRODUCT,
                    q = F === he.COMMERCE_COLLECTION,
                    W = I && (null === P || void 0 === P ? void 0 : P.username);
                return (0, u.jsxs)(st, {
                    isOpen: f,
                    onClose: b,
                    children: [(0, u.jsxs)("div", {
                        id: "ShareModalWrapper-inner",
                        className: "relative flex flex-col items-stretch rounded-t-md bg-white p-6 px-2 pb-0",
                        children: [(0, u.jsxs)("div", {
                            className: "relative flex w-full items-center justify-between",
                            children: [(0, u.jsx)("div", {
                                className: "flex grow items-center justify-center",
                                "data-testid": "ShareModal",
                                children: (0, u.jsx)("div", {
                                    className: "h-6",
                                    children: (0, u.jsx)("p", {
                                        className: "font-semibold",
                                        children: Z
                                    })
                                })
                            }), (0, u.jsx)("div", {
                                className: "absolute right-4",
                                "data-testid": "CloseButtonContainer",
                                children: (0, u.jsx)(d, {
                                    handleClose: b,
                                    "data-testid": "CloseButton"
                                })
                            })]
                        }), (0, u.jsx)("div", {
                            className: "mt-4 px-6",
                            children: (0, u.jsx)("p", {
                                className: "text-center text-stone",
                                children: z("description")
                            })
                        }), K ? (0, u.jsx)(Ze, {
                            url: p || "",
                            imageUrl: (null === m || void 0 === m ? void 0 : m.image) || void 0,
                            thumbnail: j,
                            title: w || (null === m || void 0 === m ? void 0 : m.ogTitle) || (null === m || void 0 === m ? void 0 : m.title) || T || U,
                            locked: O,
                            description: (null === m || void 0 === m ? void 0 : m.ogDescription) || (null === m || void 0 === m ? void 0 : m.description) || void 0,
                            metaData: m,
                            linkId: r,
                            isOpen: f,
                            handleLinkClick: y
                        }) : V || q ? (0, u.jsx)(Ze, {
                            url: p || "",
                            imageUrl: j,
                            thumbnail: j,
                            title: w || (null === P || void 0 === P ? void 0 : P.pageTitle) || (null === P || void 0 === P ? void 0 : P.username) || "",
                            description: (null === m || void 0 === m ? void 0 : m.ogDescription) || (null === m || void 0 === m ? void 0 : m.description) || void 0,
                            metaData: m,
                            isOpen: f,
                            handleLinkClick: y,
                            commerceStoreProductUuid: null !== g && void 0 !== g ? g : void 0
                        }) : W ? (0, u.jsx)("div", {
                            className: "px-5 pb-6",
                            children: f && (0, u.jsx)("img", {
                                className: "inline-flex rounded-lg object-cover",
                                src: "/og/image/".concat(P.username, ".jpg"),
                                alt: "profile og img",
                                onError: () => R(!1)
                            })
                        }) : (0, u.jsx)(Ze, {
                            title: w || (null === P || void 0 === P ? void 0 : P.pageTitle) || (null === P || void 0 === P ? void 0 : P.username) || "",
                            isOpen: f,
                            handleLinkClick: y
                        }), f && (0, u.jsx)(Se, {
                            shareUrl: C || p || M || "",
                            url: p,
                            closeModal: b,
                            locked: O,
                            modalType: F
                        })]
                    }), f && (0, u.jsxs)("div", {
                        className: "relative flex flex-col overflow-hidden bg-white sm:rounded-b-md",
                        children: [(0, u.jsx)(lt, {
                            username: null === P || void 0 === P ? void 0 : P.username,
                            modalType: F
                        }), (0, u.jsx)(it, {
                            username: null === P || void 0 === P ? void 0 : P.username,
                            url: p,
                            title: T,
                            shareUrl: ""
                        })]
                    })]
                })
            }
        },
        757: function(e, t, r) {
            "use strict";
            r.d(t, {
                a7: function() {
                    return c
                },
                oo: function() {
                    return l
                }
            });
            const n = /^#?([a-f\d])([a-f\d])([a-f\d])$/i,
                o = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i;

            function l(e) {
                const t = e.replace(n, ((e, t, r, n) => "#".concat(t).concat(t).concat(r).concat(r).concat(n).concat(n))),
                    r = o.exec(t);
                return r ? [parseInt(r[1], 16), parseInt(r[2], 16), parseInt(r[3], 16)] : null
            }

            function c(e, t) {
                const r = l(e);
                return r ? "rgba(".concat(r.join(","), ", ").concat(t, ")") : "rgba(0, 0, 0, 0)"
            }
        }
    }
]);