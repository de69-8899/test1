(self.__LOADABLE_LOADED_CHUNKS__ = self.__LOADABLE_LOADED_CHUNKS__ || []).push([
    [9972], {
        99972: function(n, e, i) {
            "use strict";
            i.r(e);
            var o, c = i(71383),
                d = (i(67294), i(21943)),
                l = i(50556),
                t = i(62052),
                g = i.n(t),
                a = i(89769),
                I = i(85893);
            const r = d.styled.div(o || (o = (0, c.Z)(["\n  width: 100%;\n  height: 100%;\n  position: relative;\n\n  &:before {\n    content: '';\n    position: fixed;\n    width: 100%;\n    height: 100%;\n    top: 0;\n    background-image: url(", ");\n    background-color: ", ";\n    background-repeat: no-repeat;\n    background-size: cover;\n    background-position: center;\n    opacity: 0.25;\n    filter: blur(50px);\n  }\n\n  &:after {\n    content: '';\n    position: fixed;\n    width: 100%;\n    top: 0;\n    height: 100%;\n    background-image: url(", ");\n    background-size: 512px 512px;\n    background-repeat: repeat;\n    opacity: 0.04;\n    mix-blend-mode: overlay;\n  }\n"])), (n => {
                let {
                    avatar: e
                } = n;
                return (0, a._)(e || "", "avatar-v1_0")
            }), (n => {
                let {
                    backgroundColor: e
                } = n;
                return e
            }), g());
            e.default = n => {
                let {
                    themeKey: e
                } = n;
                const {
                    account: i,
                    customAvatar: o
                } = (0, l.EG)(), c = (n => "lake-white" != n && n ? "lake-black" == n ? "#fff" : void 0 : "#000")(e);
                return (0, I.jsx)("div", {
                    className: "fixed inset-0 -z-[1]",
                    children: null !== i && void 0 !== i && i.customAvatar ? (0, I.jsx)(r, {
                        avatar: o
                    }) : (0, I.jsx)(r, {
                        backgroundColor: c
                    })
                })
            }
        },
        62052: function(n) {
            n.exports = "data:image/svg+xml;base64,PHN2ZyB2aWV3Qm94PScwIDAgNTEyIDUxMicgeG1sbnM9J2h0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnJz4KICA8ZmlsdGVyIGlkPSdub2lzZUZpbHRlcic+CiAgICA8ZmVUdXJidWxlbmNlIAogICAgICB0eXBlPSdmcmFjdGFsTm9pc2UnIAogICAgICBiYXNlRnJlcXVlbmN5PScwLjcnCiAgICAgIG51bU9jdGF2ZXM9JzMnIAogICAgICBzdGl0Y2hUaWxlcz0nc3RpdGNoJy8+CiAgICA8ZmVDb2xvck1hdHJpeCBpbj0idHVyYnVsZW5jZSIgdHlwZT0ic2F0dXJhdGUiIHZhbHVlcz0iMCIvPgoKICAgIDxmZUNvbXBvbmVudFRyYW5zZmVyPgogICAgICA8ZmVGdW5jUiB0eXBlPSJkaXNjcmV0ZSIgdGFibGVWYWx1ZXM9IjAgMSIgLz4KICAgICAgPGZlRnVuY0cgdHlwZT0iZGlzY3JldGUiIHRhYmxlVmFsdWVzPSIwIDEiIC8+CiAgICAgIDxmZUZ1bmNCIHR5cGU9ImRpc2NyZXRlIiB0YWJsZVZhbHVlcz0iMCAxIiAvPgogICAgPC9mZUNvbXBvbmVudFRyYW5zZmVyPgogIDwvZmlsdGVyPgogIAogIDxyZWN0IHdpZHRoPScxMDAlJyBoZWlnaHQ9JzEwMCUnIGZpbHRlcj0ndXJsKCNub2lzZUZpbHRlciknLz4KPC9zdmc+"
        }
    }
]);