"use strict";
(self.__LOADABLE_LOADED_CHUNKS__ = self.__LOADABLE_LOADED_CHUNKS__ || []).push([
    [403], {
        17955: function(e, t, n) {
            n.r(t);
            var r = n(59499),
                s = n(4730),
                o = n(67294),
                i = n(44080),
                l = n(89701),
                a = n(85893);
            const c = ["isOpen", "onClose", "title", "message", "status", "duration"];

            function d(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var r = Object.getOwnPropertySymbols(e);
                    t && (r = r.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), n.push.apply(n, r)
                }
                return n
            }

            function u(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? d(Object(n), !0).forEach((function(t) {
                        (0, r.Z)(e, t, n[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : d(Object(n)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                    }))
                }
                return e
            }
            const m = {
                    error: "#F5DADB",
                    warning: "#FDEFBC",
                    info: "#DCE4F7",
                    success: "#DAECDD"
                },
                f = {
                    error: "#A82418",
                    warning: "#E7B531",
                    info: "#2B5CCA",
                    success: "#276021"
                };
            t.default = e => {
                let {
                    isOpen: t,
                    onClose: n,
                    title: r,
                    message: d,
                    status: p = "success",
                    duration: h = 2e3
                } = e, v = (0, s.Z)(e, c);
                const y = (0, o.useRef)(null);
                (0, o.useEffect)((() => {
                    if (!t) return;
                    const e = setTimeout((() => {
                        j()
                    }), h);
                    return () => clearTimeout(e)
                }), [t]);
                const j = () => null === n || void 0 === n ? void 0 : n();
                return (0, a.jsx)(a.Fragment, {
                    children: (0, a.jsx)(i.u, {
                        show: t,
                        as: o.Fragment,
                        beforeEnter: () => document.documentElement.style.overflow = "",
                        afterLeave: () => document.documentElement.style.overflow = "",
                        children: (0, a.jsx)(l.V, u(u({
                            onClose: j,
                            initialFocus: y
                        }, v), {}, {
                            className: "relative pointer-events-none",
                            children: (0, a.jsxs)(a.Fragment, {
                                children: [(0, a.jsx)("div", {
                                    ref: y,
                                    "aria-hidden": "true",
                                    style: {
                                        display: "none"
                                    }
                                }), (0, a.jsx)("div", {
                                    className: "fixed inset-0 overflow-y-auto pointer-events-none",
                                    children: (0, a.jsx)("div", {
                                        className: "flex items-end justify-center min-h-full p-4 pointer-events-none",
                                        children: (0, a.jsx)(i.u.Child, {
                                            enter: "ease-out duration-300",
                                            enterFrom: "opacity-0 translate-y-4",
                                            enterTo: "opacity-100 translate-y-0",
                                            leaveFrom: "opacity-100 translate-y-0",
                                            leaveTo: "opacity-0 translate-y-4 pointer-events-none",
                                            children: (0, a.jsxs)(l.V.Panel, {
                                                className: "pointer-events-none mx-auto flex h-auto w-screen items-start rounded-sm border-2 p-4 md:w-[520px]",
                                                "data-testid": "ToastMessage",
                                                style: {
                                                    backgroundColor: m[p],
                                                    borderColor: f[p]
                                                },
                                                children: [(0, a.jsx)("svg", {
                                                    viewBox: "0 0 16 17",
                                                    className: "block",
                                                    width: "16",
                                                    height: "17",
                                                    children: (0, a.jsx)("path", {
                                                        fillRule: "evenodd",
                                                        clipRule: "evenodd",
                                                        d: "M1 8.99854C1 5.13254 4.13401 1.99854 8 1.99854C11.866 1.99854 15 5.13254 15 8.99854C15 12.8645 11.866 15.9985 8 15.9985C4.13401 15.9985 1 12.8645 1 8.99854ZM8 0.998535C3.58172 0.998535 0 4.58026 0 8.99854C0 13.4168 3.58172 16.9985 8 16.9985C12.4183 16.9985 16 13.4168 16 8.99854C16 4.58026 12.4183 0.998535 8 0.998535ZM7.92183 11.767L11.4218 6.26697L10.5782 5.7301L7.41281 10.7042L5.35355 8.64498L4.64645 9.35209L7.14645 11.8521L7.92183 11.767Z",
                                                        fill: "black"
                                                    })
                                                }), (0, a.jsxs)("div", {
                                                    className: "ml-4 space-y-2",
                                                    children: [r && (0, a.jsx)("h3", {
                                                        className: "leading-[1.2rem]",
                                                        children: r
                                                    }), d && (0, a.jsx)("p", {
                                                        className: "text-sm leading-[1.5rem]",
                                                        children: d
                                                    })]
                                                })]
                                            })
                                        })
                                    })
                                })]
                            })
                        }))
                    })
                })
            }
        }
    }
]);