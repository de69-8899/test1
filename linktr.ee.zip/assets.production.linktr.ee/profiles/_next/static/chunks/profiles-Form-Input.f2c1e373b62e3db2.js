"use strict";
(self.__LOADABLE_LOADED_CHUNKS__ = self.__LOADABLE_LOADED_CHUNKS__ || []).push([
    [1243], {
        17646: function(e, t, n) {
            n.r(t);
            var r = n(59499),
                l = n(4730),
                s = (n(67294), n(11695)),
                c = n(93967),
                i = n.n(c),
                o = n(85893);
            const a = ["prefix", "label", "input", "onChange", "className", "align"];

            function u(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var r = Object.getOwnPropertySymbols(e);
                    t && (r = r.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), n.push.apply(n, r)
                }
                return n
            }

            function p(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? u(Object(n), !0).forEach((function(t) {
                        (0, r.Z)(e, t, n[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : u(Object(n)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                    }))
                }
                return e
            }
            t.default = e => {
                let {
                    prefix: t,
                    label: n,
                    input: r,
                    onChange: c,
                    className: u,
                    align: f
                } = e, d = (0, l.Z)(e, a);
                return (0, o.jsxs)("div", {
                    className: "relative",
                    children: [n && (0, o.jsx)(s.Z, {
                        align: f,
                        htmlFor: d.id || "",
                        children: n
                    }), (0, o.jsxs)("div", {
                        className: "flex h-full w-full items-center rounded-[0.25rem] bg-chalk focus-within:outline focus-within:outline-offset-1",
                        children: [t && (0, o.jsx)("div", {
                            className: "pl-3 pr-1",
                            children: (0, o.jsx)("p", {
                                className: "text-sm text-concrete",
                                children: t
                            })
                        }), (0, o.jsx)("input", p(p({
                            className: i()(u, "h-12 w-full rounded-sm bg-transparent px-3 text-sm text-black outline-none placeholder:text-concrete"),
                            type: (null === r || void 0 === r ? void 0 : r.type) || "text",
                            onChange: e => {
                                null === c || void 0 === c || c(e), null === r || void 0 === r || r.onChange(e)
                            }
                        }, r), d))]
                    })]
                })
            }
        },
        11695: function(e, t, n) {
            n(67294);
            var r = n(85893);
            t.Z = e => {
                let {
                    align: t = "left",
                    children: n,
                    htmlFor: l = ""
                } = e;
                return (0, r.jsx)("div", {
                    className: "pb-2",
                    children: (0, r.jsx)("label", {
                        htmlFor: l,
                        className: "block font-extrabold text-xs",
                        style: {
                            textAlign: t
                        },
                        children: n
                    })
                })
            }
        }
    }
]);