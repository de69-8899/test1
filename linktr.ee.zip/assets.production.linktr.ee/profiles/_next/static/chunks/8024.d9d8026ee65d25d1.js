"use strict";
(self.__LOADABLE_LOADED_CHUNKS__ = self.__LOADABLE_LOADED_CHUNKS__ || []).push([
    [8024], {
        48024: function(o, e, r) {
            r.r(e);
            e.default = {
                key: "lake-white",
                mode: "light",
                colors: {
                    body: "#000",
                    linkBackground: "rgba(255,255,255,0.8)",
                    linkText: "#000",
                    linkShadow: "#000",
                    defaultAvatarBackground: "#60696C",
                    defaultAvatarText: "#FFFFFF"
                },
                components: {
                    SignupSubmitButton: {
                        borderLeftWidth: "2px",
                        borderLeftColor: "rgba(0,0,0, 0.1)"
                    },
                    ProfileBackground: {
                        backgroundColor: "#fff",
                        backgroundStyle: "noise"
                    },
                    ProfileDescription: {
                        color: "rgba(0,0,0, 0.6)"
                    },
                    LinkContainer: {
                        borderRadius: "4px",
                        embedContentRadius: "4px",
                        styleType: "fill-scale-shadow"
                    },
                    LinkHeader: {
                        color: "#000"
                    },
                    LinkThumbnail: {
                        borderRadius: "4px",
                        size: "48px"
                    },
                    SocialLink: {
                        fill: "#000"
                    },
                    Banner: {
                        default: {
                            backgroundColor: "rgba(255,255,255,0.8)",
                            color: "#000"
                        }
                    },
                    Footer: {
                        logo: "black"
                    }
                }
            }
        }
    }
]);