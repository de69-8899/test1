self.__BUILD_MANIFEST = function(e, s, a, t) {
    return {
        __rewrites: {
            beforeFiles: [],
            afterFiles: [{
                source: "/:nextInternalLocale(en)/api/profiles/sticker/:username.png",
                destination: "/:nextInternalLocale/api/profiles/sticker/:username"
            }, {
                source: "/:nextInternalLocale(en)/api/profiles/og/image/:username.jpg",
                destination: "/:nextInternalLocale/api/profiles/og/image/:username"
            }],
            fallback: []
        },
        "/_error": ["static/chunks/pages/_error-59e6edcbf77d1e12.js"],
        "/auth/spotifyCallback": ["static/chunks/pages/auth/spotifyCallback-db931b1f7a037f54.js"],
        "/status/blocked": ["static/chunks/pages/status/blocked-c03fad9984191294.js"],
        "/[profile]": [e, a, s, t, "static/chunks/pages/[profile]-0b88300683809241.js"],
        "/[profile]/media-kit": [e, "static/chunks/185-acc4af677787ccc0.js", s, "static/chunks/pages/[profile]/media-kit-647fc611828be0a1.js"],
        "/[profile]/shop": [e, a, s, t, "static/chunks/pages/[profile]/shop-3ecd936e67ced8aa.js"],
        "/[profile]/store": [e, a, s, t, "static/chunks/pages/[profile]/store-b09273a5fefc4514.js"],
        sortedPages: ["/_app", "/_error", "/auth/spotifyCallback", "/status/blocked", "/[profile]", "/[profile]/media-kit", "/[profile]/shop", "/[profile]/store"]
    }
}("static/chunks/4301-7a079b6e73ecde9d.js", "static/chunks/8858-f280153e7317c5d4.js", "static/chunks/236-bc2d48d9ca27c2da.js", "static/chunks/9036-f1d34fad4922690a.js"), self.__BUILD_MANIFEST_CB && self.__BUILD_MANIFEST_CB();