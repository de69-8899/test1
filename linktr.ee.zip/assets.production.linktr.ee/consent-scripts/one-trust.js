(() => {
    "use strict";
    var t, e = {
            340: (t, e) => {
                Object.defineProperty(e, "__esModule", {
                    value: !0
                }), e.COOKIE_UPDATE_EVENT = void 0, e.COOKIE_UPDATE_EVENT = "cookie-update-event"
            },
            809: (t, e, n) => {
                Object.defineProperty(e, "__esModule", {
                    value: !0
                }), e.generateOptanonWrapper = void 0;
                var o = n(340),
                    r = function() {
                        return window.OnetrustActiveGroups ? window.OnetrustActiveGroups.split(",").filter(Boolean) : []
                    },
                    a = function() {
                        window.OnetrustActiveGroups ? (c(), s()) : setTimeout(a, 100)
                    },
                    i = function(t) {
                        var e;
                        if ("text/plain" === t.type && (t.className || "").includes("optanon-category-")) {
                            var n = r(),
                                o = t.className.split(" ").find((function(t) {
                                    return t.includes("optanon-category-")
                                }));
                            if (o && o.replace("optanon-category-", "").split("-").every((function(t) {
                                    return n.includes(t)
                                }))) {
                                var a = t.cloneNode(!0);
                                a.type = "text/javascript", null === (e = t.parentElement) || void 0 === e || e.insertBefore(a, t), t.remove()
                            }
                        }
                    },
                    c = function() {
                        var t = document.querySelectorAll('script[type="text/plain"]');
                        t && t.forEach((function(t) {
                            t instanceof HTMLScriptElement && i(t)
                        }))
                    },
                    s = function() {
                        new MutationObserver((function(t) {
                            for (var e = 0, n = t; e < n.length; e++) n[e].addedNodes.forEach((function(t) {
                                t instanceof HTMLScriptElement && i(t)
                            }))
                        })).observe(document.head, {
                            childList: !0,
                            attributes: !0,
                            attributeFilter: ["src", "type", "class"]
                        })
                    };
                e.generateOptanonWrapper = function() {
                    var t, e = function(t) {
                        var e = t.name,
                            n = t.domain,
                            o = t.path,
                            r = "".concat(e, "=;expires=Thu, 01 Jan 1970 00:00:00 UTC;max-age=0;").concat(o ? "path=/;" : "").concat(n ? "domain=".concat(n, ";") : "");
                        document.cookie = r
                    };
                    t = [], window.OptanonWrapper = function() {
                        window.postMessage(o.COOKIE_UPDATE_EVENT);
                        var n = r(),
                            a = t.filter((function(t) {
                                return !n.includes(t)
                            }));
                        t = n;
                        var i = window.Optanon.GetDomainData().Groups.filter((function(t) {
                            return a.includes(t.OptanonGroupId)
                        }));
                        i.forEach((function(t) {
                            t.Cookies.forEach((function(t) {
                                e({
                                    name: t.Name
                                }), e({
                                    name: t.Name,
                                    domain: t.Host
                                }), e({
                                    name: t.Name,
                                    domain: ".".concat(t.Host)
                                }), e({
                                    name: t.Name,
                                    path: "/"
                                }), e({
                                    name: t.Name,
                                    domain: t.Host,
                                    path: "/"
                                }), e({
                                    name: t.Name,
                                    domain: ".".concat(t.Host),
                                    path: "/"
                                }), localStorage.removeItem(t.Name), sessionStorage.removeItem(t.Name)
                            }))
                        })), i.length && setTimeout((function() {
                            window.location.reload()
                        }), 500)
                    }, a()
                }
            },
            145: function(t, e) {
                var n = this && this.__rest || function(t, e) {
                        var n = {};
                        for (var o in t) Object.prototype.hasOwnProperty.call(t, o) && e.indexOf(o) < 0 && (n[o] = t[o]);
                        if (null != t && "function" == typeof Object.getOwnPropertySymbols) {
                            var r = 0;
                            for (o = Object.getOwnPropertySymbols(t); r < o.length; r++) e.indexOf(o[r]) < 0 && Object.prototype.propertyIsEnumerable.call(t, o[r]) && (n[o[r]] = t[o[r]])
                        }
                        return n
                    },
                    o = this && this.__spreadArray || function(t, e, n) {
                        if (n || 2 === arguments.length)
                            for (var o, r = 0, a = e.length; r < a; r++) !o && r in e || (o || (o = Array.prototype.slice.call(e, 0, r)), o[r] = e[r]);
                        return t.concat(o || Array.prototype.slice.call(e))
                    };
                Object.defineProperty(e, "__esModule", {
                    value: !0
                }), e.generateScript = void 0, e.generateScript = function(t) {
                    var e = t.cookieCategories,
                        r = t.customAttrs,
                        a = void 0 === r ? {} : r,
                        i = n(t, ["cookieCategories", "customAttrs"]),
                        c = document.createElement("script");
                    c.type = e.length ? "text/plain" : "text/javascript";
                    var s = o(["optanon-category"], e.sort(), !0).join("-");
                    c.classList.add(s), Object.assign(c, i), Object.entries(a).forEach((function(t) {
                        var e = t[0],
                            n = t[1];
                        c.setAttribute(e, n)
                    })), document.head.appendChild(c)
                }
            }
        },
        n = {};

    function o(t) {
        var r = n[t];
        if (void 0 !== r) return r.exports;
        var a = n[t] = {
            exports: {}
        };
        return e[t].call(a.exports, a, a.exports, o), a.exports
    }
    t = o(145), (0, o(809).generateOptanonWrapper)(), (0, t.generateScript)({
        src: "https://cdn-au.onetrust.com/scripttemplates/otSDKStub.js",
        cookieCategories: [],
        customAttrs: {
            "data-domain-script": "d5c19ad0-1f05-4c37-9934-1585c94aab5c"
        }
    })
})();